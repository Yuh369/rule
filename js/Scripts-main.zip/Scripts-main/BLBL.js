
[rewrite_remote]

https://raw.githubusercontent.com/WeiRen0/Scripts/main/BLBL.js, tag=哔站脚本需要赞助30元才可以拥有。谢谢大家的赞助与支持！, update-interval=172800, opt-parser=true, enabled=true
