/******************************

脚本功能：轻图解锁永久专业版
软件版本：3.5.10
下载地址：http://t.cn/A6C9a3ec
脚本作者：Hausd0rff
更新时间：2023-03-08
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 轻图解锁永久专业版
^https?:\/\/purchase-qingtu-api\.b612kaji\.com\/v1\/purchase\/subscription\/subscriber/status$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/PhotoVisionProCrack.js

[mitm] 
hostname = purchase-qingtu-api.b612kaji.com

*******************************/

var _0x5565db=_0x1d0c;function _0x1d0c(_0x40df8b,_0x5604fb){var _0x18a693=_0x18a6();return _0x1d0c=function(_0x1d0c37,_0x49af79){_0x1d0c37=_0x1d0c37-0x175;var _0x29cb84=_0x18a693[_0x1d0c37];return _0x29cb84;},_0x1d0c(_0x40df8b,_0x5604fb);}(function(_0x25e254,_0xad37a8){var _0x11c994=_0x1d0c,_0x319b58=_0x25e254();while(!![]){try{var _0x3c5d6a=parseInt(_0x11c994(0x17a))/0x1*(parseInt(_0x11c994(0x179))/0x2)+parseInt(_0x11c994(0x178))/0x3+parseInt(_0x11c994(0x181))/0x4*(parseInt(_0x11c994(0x177))/0x5)+-parseInt(_0x11c994(0x17e))/0x6+parseInt(_0x11c994(0x176))/0x7*(-parseInt(_0x11c994(0x175))/0x8)+parseInt(_0x11c994(0x17b))/0x9+-parseInt(_0x11c994(0x17f))/0xa*(parseInt(_0x11c994(0x17d))/0xb);if(_0x3c5d6a===_0xad37a8)break;else _0x319b58['push'](_0x319b58['shift']());}catch(_0x43ffc4){_0x319b58['push'](_0x319b58['shift']());}}}(_0x18a6,0x7d7ad),$done({'body':JSON[_0x5565db(0x17c)]({'result':{'activated':!![],'products':[{'managed':!![],'status':_0x5565db(0x180),'startDate':0x184bef77418,'productId':'com.photovision.camera.subscribe.plan.oneyear','expireDate':0x1d8f2ea38c18}]}})}));function _0x18a6(){var _0x530f34=['2789391fMYBDs','1834584juxyXh','80CTdySE','ACTIVE','4XSJtwO','891040NWpiTK','14ANUotm','5101270WrbOnL','1400529lBAkvv','14772bNgHiM','116CVVGXp','6545376ZcBvrv','stringify'];_0x18a6=function(){return _0x530f34;};return _0x18a6();}
