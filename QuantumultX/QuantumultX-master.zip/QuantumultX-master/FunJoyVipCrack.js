/******************************

脚本功能：饭橘减肥解锁永久会员
软件版本：1.4.6
下载地址：http://t.cn/A6N3ggod
脚本作者：Hausd0rff
更新时间：2023-05-13
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 饭橘减肥解锁永久会员
^https?:\/\/funjoy-api\.aiyouaiyou\.cn\/api\/User\/GetInfoByCode$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/FunJoyVipCrack.js

[mitm] 
hostname = funjoy-api.aiyouaiyou.cn

*******************************/

var _0x587358=_0x1006;function _0x1006(_0x5b0a5e,_0x4e98cc){var _0x23e48=_0x23e4();return _0x1006=function(_0x1006f9,_0x248ead){_0x1006f9=_0x1006f9-0x199;var _0x2fead2=_0x23e48[_0x1006f9];return _0x2fead2;},_0x1006(_0x5b0a5e,_0x4e98cc);}(function(_0x1b3f5f,_0x33e7c8){var _0x7bc49c=_0x1006,_0x4fa80c=_0x1b3f5f();while(!![]){try{var _0x445103=parseInt(_0x7bc49c(0x199))/0x1+parseInt(_0x7bc49c(0x19b))/0x2*(parseInt(_0x7bc49c(0x19d))/0x3)+-parseInt(_0x7bc49c(0x1a3))/0x4*(parseInt(_0x7bc49c(0x1a2))/0x5)+-parseInt(_0x7bc49c(0x1a9))/0x6*(-parseInt(_0x7bc49c(0x19e))/0x7)+parseInt(_0x7bc49c(0x1a5))/0x8+-parseInt(_0x7bc49c(0x1a1))/0x9+parseInt(_0x7bc49c(0x19f))/0xa*(-parseInt(_0x7bc49c(0x1a6))/0xb);if(_0x445103===_0x33e7c8)break;else _0x4fa80c['push'](_0x4fa80c['shift']());}catch(_0x51558e){_0x4fa80c['push'](_0x4fa80c['shift']());}}}(_0x23e4,0x8420e));var body=$response['\x62\x6f\x64\x79'],hausd0rff=JSON[_0x587358(0x1aa)](body);function _0x23e4(){var _0x4d8a52=['\u203c\ufe0f\u89c4\u5219\u5b8c\u5168\u514d\u8d39\uff0c\u4ec5\u4f9b\u5b66\u4e60\u4ea4\u6d41\uff0c\ud83c\ude32\ufe0f\u5546\u4e1a\u7528\u9014\uff01\u66f4\u591a\u7834\u89e3\ud83d\udc49 \x68\x74\x74\x70\x73\x3a\x2f\x2f\x74\x2e\x6d\x65\x2f\x79\x71\x63\x5f\x31\x32\x33','425754gSqIXX','\x69\x73\x5f\x76\x69\x70','6LGjDqm','2682393BUrrGq','210410xoBczD','\ud835\udc3b\ud835\udc4e\ud835\udc62\ud835\udc60\ud835\udc51\ud835\udc5c\ud835\udc5f\ud835\udc53\ud835\udc53 \ud835\udc36\ud835\udc5f\ud835\udc4e\ud835\udc50\ud835\udc58','5807916etuUkc','395YXrXgl','42956bDSHad','\x64\x61\x74\x61','2576304eqCwYn','33zYRzaV','\x76\x69\x70\x5f\x65\x6e\x64\x5f\x74\x69\x6d\x65','\x6e\x61\x6d\x65','6GxLlUf','\x70\x61\x72\x73\x65','967035OZGTyj'];_0x23e4=function(){return _0x4d8a52;};return _0x23e4();}hausd0rff[_0x587358(0x1a4)][_0x587358(0x19c)]=0x1,hausd0rff[_0x587358(0x1a4)][_0x587358(0x1a7)]=0x790e11d00,hausd0rff[_0x587358(0x1a4)][_0x587358(0x1a8)]=_0x587358(0x1a0),hausd0rff[_0x587358(0x1a4)]['\x69\x6e\x74\x72\x6f\x64\x75\x63\x74\x69\x6f\x6e']=_0x587358(0x19a),$done({'\x62\x6f\x64\x79':JSON['\x73\x74\x72\x69\x6e\x67\x69\x66\x79'](hausd0rff)});
