/******************************

脚本功能：加藤破解全部视频
软件版本：2.0.2
下载地址：https://bit.ly/3Z40048
脚本作者：Hausd0rff
更新时间：2023-02-16
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 加藤视频破解全部视频
^https?:\/\/api\.jttv01\.cc\/shorter\/video\/longvideoinfo\/info.+ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/JiaTengVideoAllCrack.js

[mitm] 
hostname = api.jttv01.cc

*******************************/

function _0x18ab(_0x341826,_0x53beba){var _0x3e891e=_0x3e89();return _0x18ab=function(_0x18ab58,_0x33812a){_0x18ab58=_0x18ab58-0x1d8;var _0x2b893b=_0x3e891e[_0x18ab58];return _0x2b893b;},_0x18ab(_0x341826,_0x53beba);}var _0x158f2b=_0x18ab;(function(_0x46d1e0,_0x5962dc){var _0x4205d2=_0x18ab,_0xf0a780=_0x46d1e0();while(!![]){try{var _0x3ee55c=-parseInt(_0x4205d2(0x1e7))/0x1+parseInt(_0x4205d2(0x1dc))/0x2+-parseInt(_0x4205d2(0x1e3))/0x3*(-parseInt(_0x4205d2(0x1e6))/0x4)+parseInt(_0x4205d2(0x1d9))/0x5+-parseInt(_0x4205d2(0x1df))/0x6*(-parseInt(_0x4205d2(0x1de))/0x7)+-parseInt(_0x4205d2(0x1dd))/0x8+-parseInt(_0x4205d2(0x1e2))/0x9;if(_0x3ee55c===_0x5962dc)break;else _0xf0a780['push'](_0xf0a780['shift']());}catch(_0x360061){_0xf0a780['push'](_0xf0a780['shift']());}}}(_0x3e89,0x56e10));var body=$response['body'],objc=JSON['parse'](body);objc[_0x158f2b(0x1d8)][_0x158f2b(0x1da)]=0x0,objc[_0x158f2b(0x1d8)][_0x158f2b(0x1e1)]=0x1,objc[_0x158f2b(0x1d8)]['isCharge']=0x0,objc[_0x158f2b(0x1d8)][_0x158f2b(0x1db)]=0x0;var VideoUrl=objc[_0x158f2b(0x1d8)][_0x158f2b(0x1e5)][_0x158f2b(0x1e4)](/try/,'trailer');objc['data'][_0x158f2b(0x1e0)]=VideoUrl,$done({'body':JSON['stringify'](objc)});function _0x3e89(){var _0x248bf7=['tryVideoUrl','36EPfhNd','6593MQqbVj','data','392990tufbXn','isVip','isTrysee','198886XHzKmy','944136RAerAG','17269yKrUdH','1614KynvNq','videoUrl','userVip','4374414ZkfpYw','41616VCIZkj','replace'];_0x3e89=function(){return _0x248bf7;};return _0x3e89();}
