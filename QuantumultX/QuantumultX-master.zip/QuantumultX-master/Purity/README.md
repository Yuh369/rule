Utility Scripts: functions such as sanitization and de-advertising

实用性脚本：净化和去广告等功能
