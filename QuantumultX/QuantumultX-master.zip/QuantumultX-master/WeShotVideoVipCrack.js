/******************************

脚本功能：可拍解锁永久会员
软件版本：2.4.6
下载地址：http://t.cn/A6KxWZn1
脚本作者：Passer_by_yun
更新时间：2022-11-28
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 可拍解锁永久会员
^https?:\/\/fxshot-api\.afunapp\.com\/order_api\/apple_query$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/WeShotVideoVipCrack.js

[mitm] 
hostname = fxshot-api.afunapp.com

*******************************/

function _0x4966(_0xdc4a6b,_0x1017dc){var _0x53c0ec=_0x53c0();return _0x4966=function(_0x4966a8,_0x3c5aef){_0x4966a8=_0x4966a8-0x105;var _0x434dee=_0x53c0ec[_0x4966a8];return _0x434dee;},_0x4966(_0xdc4a6b,_0x1017dc);}function _0x53c0(){var _0x531ede=['7Fqlliz','1281147JYKAzt','597380XYDiZd','data','6171552ZJsiwe','8563256GQAfWb','2428794tVnGhW','934724TGWmHK','3253040odqlox'];_0x53c0=function(){return _0x531ede;};return _0x53c0();}var _0x538298=_0x4966;(function(_0x48577f,_0x55ccb5){var _0x4e1772=_0x4966,_0xdae08d=_0x48577f();while(!![]){try{var _0x350f52=-parseInt(_0x4e1772(0x10c))/0x1+parseInt(_0x4e1772(0x10b))/0x2+-parseInt(_0x4e1772(0x106))/0x3+parseInt(_0x4e1772(0x10d))/0x4+parseInt(_0x4e1772(0x107))/0x5+parseInt(_0x4e1772(0x109))/0x6+-parseInt(_0x4e1772(0x105))/0x7*(parseInt(_0x4e1772(0x10a))/0x8);if(_0x350f52===_0x55ccb5)break;else _0xdae08d['push'](_0xdae08d['shift']());}catch(_0x248861){_0xdae08d['push'](_0xdae08d['shift']());}}}(_0x53c0,0xb5879));var objc=JSON['parse']($response['body']);objc[_0x538298(0x108)]['vip_remain_time']=0x790e19db5,$done({'body':JSON['stringify'](objc)});
