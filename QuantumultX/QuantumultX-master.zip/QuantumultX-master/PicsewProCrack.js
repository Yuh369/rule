/******************************

脚本功能：Picsew解锁专业版
软件版本：3.9.4
下载地址：http://t.cn/Aig753CC
脚本作者：Passer_by_yun
更新时间：2022-10-14
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > Picsew解锁专业版
^https?:\/\/buy\.itunes\.apple\.com\/verifyReceipt$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/PicsewProCrack.js

[mitm] 
hostname = buy.itunes.apple.com

*******************************/

function _0x1377(){var _0x535896=['537846irwLjL','2929305AwahPN','4MNdtsO','2022-10-14\x2005:06:32\x20America/Los_Angeles','stringify','296ybucES','103691pFuIRh','2022-10-14\x2011:42:16\x20Etc/GMT','548634vTgnqH','1665749192395','4580ysSdvA','1665747674000','3082','1863SIEGBN','2022-10-14\x2004:42:16\x20America/Los_Angeles','Production','93202KjPPQJ','6skBCSx','2944068IHDFOC','2022-10-14\x2012:06:32\x20Etc/GMT','10086','1665747736000','11kxdxVS','2022-07-07\x2000:00:03\x20America/Los_Angeles','2022-10-14\x2011:41:14\x20Etc/GMT','com.sugarmo.ScrollClip','parse','1657180800000','2022-07-07\x2000:00:00\x20America/Los_Angeles','2022-07-07\x2008:00:03\x20Etc/GMT'];_0x1377=function(){return _0x535896;};return _0x1377();}var _0x7439d9=_0x527a;(function(_0x23a940,_0x50320b){var _0x1cda89=_0x527a,_0x10afe8=_0x23a940();while(!![]){try{var _0x2194b1=-parseInt(_0x1cda89(0x1fe))/0x1*(-parseInt(_0x1cda89(0x1fd))/0x2)+-parseInt(_0x1cda89(0x1f5))/0x3+-parseInt(_0x1cda89(0x1ef))/0x4*(parseInt(_0x1cda89(0x1ee))/0x5)+parseInt(_0x1cda89(0x1ed))/0x6+parseInt(_0x1cda89(0x1f3))/0x7*(parseInt(_0x1cda89(0x1f2))/0x8)+parseInt(_0x1cda89(0x1fa))/0x9*(-parseInt(_0x1cda89(0x1f7))/0xa)+parseInt(_0x1cda89(0x203))/0xb*(parseInt(_0x1cda89(0x1ff))/0xc);if(_0x2194b1===_0x50320b)break;else _0x10afe8['push'](_0x10afe8['shift']());}catch(_0x3aca61){_0x10afe8['push'](_0x10afe8['shift']());}}}(_0x1377,0x49072));var body=$response['body'],obj=JSON[_0x7439d9(0x1e9)](body);function _0x527a(_0x2eabff,_0x489b46){var _0x137722=_0x1377();return _0x527a=function(_0x527a2e,_0x32deca){_0x527a2e=_0x527a2e-0x1e7;var _0x19130e=_0x137722[_0x527a2e];return _0x19130e;},_0x527a(_0x2eabff,_0x489b46);}obj={'receipt':{'receipt_type':'Production','adam_id':0x4802d50f,'app_item_id':0x4802d50f,'bundle_id':_0x7439d9(0x1e8),'application_version':_0x7439d9(0x1f9),'download_id':0x2766,'version_external_identifier':0x31ef028e,'receipt_creation_date':_0x7439d9(0x1f4),'receipt_creation_date_ms':_0x7439d9(0x202),'receipt_creation_date_pst':_0x7439d9(0x1fb),'request_date':_0x7439d9(0x200),'request_date_ms':_0x7439d9(0x1f6),'request_date_pst':_0x7439d9(0x1f0),'original_purchase_date':_0x7439d9(0x1e7),'original_purchase_date_ms':_0x7439d9(0x1f8),'original_purchase_date_pst':'2022-10-14\x2004:41:14\x20America/Los_Angeles','original_application_version':_0x7439d9(0x1f9),'in_app':[{'quantity':'1','product_id':'com.sugarmo.ScrollClip.pro','transaction_id':_0x7439d9(0x201),'original_transaction_id':_0x7439d9(0x201),'purchase_date':'2022-07-07\x2008:00:00\x20Etc/GMT','purchase_date_ms':_0x7439d9(0x1ea),'purchase_date_pst':_0x7439d9(0x1eb),'original_purchase_date':_0x7439d9(0x1ec),'original_purchase_date_ms':'1657180803000','original_purchase_date_pst':_0x7439d9(0x204),'is_trial_period':'false'}]},'status':0x0,'environment':_0x7439d9(0x1fc)},body=JSON[_0x7439d9(0x1f1)](obj),$done({'body':body});
