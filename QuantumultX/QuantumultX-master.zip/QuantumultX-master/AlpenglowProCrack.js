/******************************

脚本功能：Alpenglow解锁永久高级版
软件版本：8.1.4
下载地址：http://t.cn/A6K0Hmdj
脚本作者：Passer_by_yun
更新时间：2022-11-03
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > Alpenglow解锁永久高级版
^https?:\/\/api\.revenuecat\.com\/v1\/(receipts|subscribers\/\$RCAnonymousID%3A\w{32})$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/AlpenglowProCrack.js

[mitm] 
hostname = api.revenuecat.com

*******************************/

var _0x401ab4=_0x19db;(function(_0x4b337e,_0x7538dd){var _0x4d6565=_0x19db,_0x260772=_0x4b337e();while(!![]){try{var _0x3b6970=parseInt(_0x4d6565(0x72))/0x1*(parseInt(_0x4d6565(0x7c))/0x2)+-parseInt(_0x4d6565(0x6d))/0x3+-parseInt(_0x4d6565(0x71))/0x4+parseInt(_0x4d6565(0x79))/0x5*(-parseInt(_0x4d6565(0x70))/0x6)+-parseInt(_0x4d6565(0x78))/0x7+parseInt(_0x4d6565(0x7b))/0x8*(parseInt(_0x4d6565(0x74))/0x9)+-parseInt(_0x4d6565(0x6e))/0xa*(-parseInt(_0x4d6565(0x7a))/0xb);if(_0x3b6970===_0x7538dd)break;else _0x260772['push'](_0x260772['shift']());}catch(_0x5ab3e1){_0x260772['push'](_0x260772['shift']());}}}(_0x1af5,0xe513c));function _0x1af5(){var _0x355ae9=['2022-11-03T01:45:39Z','4139358tFQvsQ','116650YFXJQJ','parse','1652142siHRlm','4598668xdqDgq','128EVwxnm','2013-08-01T07:00:00Z','90RwmDBx','$RCAnonymousID:11d6899808b64fdfb1e7b3f179308853','1.0','Passer_by_yun','8365819Myuyjh','10aUVwcU','4598oiWOYJ','225752bxRXEN','866aFPlFo','app_store','2022-11-03T01:47:10Z','2022-11-03T01:47:48Z','stringify'];_0x1af5=function(){return _0x355ae9;};return _0x1af5();}function _0x19db(_0x4e2a28,_0x270806){var _0x1af53a=_0x1af5();return _0x19db=function(_0x19db82,_0x4f92ea){_0x19db82=_0x19db82-0x6b;var _0x563b89=_0x1af53a[_0x19db82];return _0x563b89;},_0x19db(_0x4e2a28,_0x270806);}var body=$response['body'],obj=JSON[_0x401ab4(0x6f)](body);obj={'request_date_ms':0x1843b2c485b,'request_date':_0x401ab4(0x7f),'subscriber':{'non_subscriptions':{'ProLifetime':[{'id':_0x401ab4(0x77),'is_sandbox':!![],'purchase_date':_0x401ab4(0x7e),'original_purchase_date':_0x401ab4(0x7e),'store':_0x401ab4(0x7d)}]},'first_seen':_0x401ab4(0x6c),'original_application_version':_0x401ab4(0x76),'other_purchases':{'ProLifetime':{'purchase_date':'2022-11-03T01:47:10Z'}},'management_url':null,'subscriptions':{},'entitlements':{'newPro':{'grace_period_expires_date':null,'purchase_date':_0x401ab4(0x7e),'product_identifier':'ProLifetime','expires_date':null}},'original_purchase_date':_0x401ab4(0x73),'original_app_user_id':_0x401ab4(0x75),'last_seen':_0x401ab4(0x6c)}},body=JSON[_0x401ab4(0x6b)](obj),$done({'body':body});
