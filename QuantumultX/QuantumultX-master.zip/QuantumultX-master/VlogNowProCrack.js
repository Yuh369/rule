/******************************

脚本功能：VN视频剪辑解锁订阅
软件版本：1.59.2
下载地址：http://t.cn/A6K5dGGw
脚本作者：Passer_by_yun
更新时间：2022-10-22
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > VN视频剪辑解锁订阅
^https?:\/\/api2\.vlognow\.me\/vn-pay\/api\/v1\/public\/iap\/receipt\/status url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/VlogNowProCrack.js

[mitm] 
hostname = api2.vlognow.me

*******************************/

var _0x26c345=_0x2d46;(function(_0x197d76,_0x124398){var _0xd13a78=_0x2d46,_0x4c621c=_0x197d76();while(!![]){try{var _0x1ea8a4=parseInt(_0xd13a78(0xaa))/0x1+-parseInt(_0xd13a78(0xae))/0x2*(parseInt(_0xd13a78(0xa9))/0x3)+-parseInt(_0xd13a78(0xb2))/0x4+-parseInt(_0xd13a78(0xa4))/0x5*(-parseInt(_0xd13a78(0xa7))/0x6)+-parseInt(_0xd13a78(0xb1))/0x7+-parseInt(_0xd13a78(0xa8))/0x8+-parseInt(_0xd13a78(0xab))/0x9*(-parseInt(_0xd13a78(0xb0))/0xa);if(_0x1ea8a4===_0x124398)break;else _0x4c621c['push'](_0x4c621c['shift']());}catch(_0xd3971){_0x4c621c['push'](_0x4c621c['shift']());}}}(_0x28be,0x97062));var body=$response[_0x26c345(0xa5)],obj=JSON[_0x26c345(0xaf)](body);function _0x2d46(_0x588d76,_0x110bd4){var _0x28be0f=_0x28be();return _0x2d46=function(_0x2d467b,_0x2404a6){_0x2d467b=_0x2d467b-0xa4;var _0x35e3b8=_0x28be0f[_0x2d467b];return _0x35e3b8;},_0x2d46(_0x588d76,_0x110bd4);}obj={'msg':_0x26c345(0xa6),'data':[{'status':0x1,'is_free_trial':![],'active':!![],'product_identifier':_0x26c345(0xac),'enanled_auto_renew':![],'is_gift_subscription':![],'platform':_0x26c345(0xb3),'billing_date_ms':0x18484b6cb78,'original_purchase_date_ms':0x18484b41fe0,'start_date_ms':0x18484b40c58,'expires_date_ms':0x315f366d800,'group_identifier':'20936308','origin_transaction_id':_0x26c345(0xad)}],'code':0x1},body=JSON['stringify'](obj),$done({'body':body});function _0x28be(){var _0x4ca235=['1017012wgarlm','77252NYhYyK','9wATtta','Product_Auto_Renew_Annual_2022_05_13','10086','4ycAYGq','parse','18965520SPyeSS','2142693SgLbVV','3246004lQhWjP','iOS','1642010oTjpoS','body','success','18zCUrPR','4358464OMUghB'];_0x28be=function(){return _0x4ca235;};return _0x28be();}
