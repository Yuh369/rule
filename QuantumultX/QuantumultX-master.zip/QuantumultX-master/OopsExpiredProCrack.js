/******************************

脚本功能：过期啦解锁永久订阅
软件版本：3.0.3
下载地址：http://t.cn/A6trSJHS
脚本作者：Passer_by_yun
更新时间：2022-12-19
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 过期啦解锁永久订阅
^https?:\/\/api\.revenuecat\.com\/v1\/(receipts|subscribers\/).+ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/OopsExpiredProCrack.js

[mitm] 
hostname = api.revenuecat.com

*******************************/

var _0x29b3c6=_0x3b9e;(function(_0x2733f9,_0x3c1c39){var _0x48a5ce=_0x3b9e,_0x36013c=_0x2733f9();while(!![]){try{var _0xeda698=parseInt(_0x48a5ce(0x147))/0x1*(parseInt(_0x48a5ce(0x149))/0x2)+-parseInt(_0x48a5ce(0x14a))/0x3+-parseInt(_0x48a5ce(0x14f))/0x4*(-parseInt(_0x48a5ce(0x156))/0x5)+-parseInt(_0x48a5ce(0x13e))/0x6*(-parseInt(_0x48a5ce(0x151))/0x7)+-parseInt(_0x48a5ce(0x140))/0x8+-parseInt(_0x48a5ce(0x144))/0x9+-parseInt(_0x48a5ce(0x141))/0xa;if(_0xeda698===_0x3c1c39)break;else _0x36013c['push'](_0x36013c['shift']());}catch(_0x175cab){_0x36013c['push'](_0x36013c['shift']());}}}(_0x4689,0xebabc));var body=$response[_0x29b3c6(0x145)],objc=JSON[_0x29b3c6(0x148)](body);function _0x3b9e(_0x1c7dc0,_0x517680){var _0x4689ba=_0x4689();return _0x3b9e=function(_0x3b9e0b,_0x30eabd){_0x3b9e0b=_0x3b9e0b-0x13e;var _0x568ea4=_0x4689ba[_0x3b9e0b];return _0x568ea4;},_0x3b9e(_0x1c7dc0,_0x517680);}function _0x4689(){var _0x2af020=['4640900UzPAmJ','stringify','788','4891851PPwHZy','body','2022-12-23T10:58:32Z','1016113sWFmQA','parse','2diemFC','2101623wcsZnF','2022-12-23T14:46:43Z','2022-12-23T10:56:29Z','PURCHASED','https://apps.apple.com/account/subscriptions','214072knTuJE','com.vanemu.oops_expired.pro','1637769BjfXwb','trial','2999-12-28T11:13:20Z','2022-12-23T11:13:20Z','$RCAnonymousID:fdc1d2576ae14747a8b0d97085684dc0','155VDJSdS','42UKiytK','app_store','13115696bBFVJL'];_0x4689=function(){return _0x2af020;};return _0x4689();}objc={'request_date_ms':0x1853f735cca,'request_date':_0x29b3c6(0x14b),'subscriber':{'non_subscriptions':{},'first_seen':_0x29b3c6(0x14c),'original_application_version':_0x29b3c6(0x143),'other_purchases':{},'management_url':_0x29b3c6(0x14e),'subscriptions':{'com.vanemu.oops_expired.pro':{'original_purchase_date':'2022-12-23T11:13:22Z','expires_date':_0x29b3c6(0x153),'is_sandbox':![],'refunded_at':null,'unsubscribe_detected_at':'2022-12-23T11:34:58Z','grace_period_expires_date':null,'period_type':_0x29b3c6(0x152),'purchase_date':_0x29b3c6(0x154),'billing_issues_detected_at':null,'ownership_type':_0x29b3c6(0x14d),'store':_0x29b3c6(0x13f),'auto_resume_date':null}},'entitlements':{'pro':{'grace_period_expires_date':null,'purchase_date':_0x29b3c6(0x154),'product_identifier':_0x29b3c6(0x150),'expires_date':_0x29b3c6(0x153)}},'original_purchase_date':'2022-12-23T10:56:00Z','original_app_user_id':_0x29b3c6(0x155),'last_seen':_0x29b3c6(0x146)}},body=JSON[_0x29b3c6(0x142)](objc),$done({'body':body});
