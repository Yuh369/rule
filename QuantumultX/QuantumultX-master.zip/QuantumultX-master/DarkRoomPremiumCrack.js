/******************************

脚本功能：DarkRoom 解锁永久高级版
软件版本：6.3.4
下载地址：http://t.cn/A6C4zYZu
脚本作者：Hausd0rff
更新时间：2023-02-19
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > DarkRoom 解锁永久高级版
^https?:\/\/api\.revenuecat\.com\/v1\/(receipts|subscribers\/\$RCAnonymousID%3A\w{32}) url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/DarkRoomPremiumCrack.js

[mitm] 
hostname = api.revenuecat.com

*******************************/

var _0x4fec3a=_0x3e31;(function(_0x2f94e7,_0x257c77){var _0x1d7cb9=_0x3e31,_0x449fc9=_0x2f94e7();while(!![]){try{var _0xccd02e=-parseInt(_0x1d7cb9(0x1cc))/0x1*(parseInt(_0x1d7cb9(0x1c5))/0x2)+-parseInt(_0x1d7cb9(0x1c9))/0x3+parseInt(_0x1d7cb9(0x1bb))/0x4*(parseInt(_0x1d7cb9(0x1bc))/0x5)+-parseInt(_0x1d7cb9(0x1c7))/0x6*(parseInt(_0x1d7cb9(0x1c0))/0x7)+parseInt(_0x1d7cb9(0x1ba))/0x8*(parseInt(_0x1d7cb9(0x1c6))/0x9)+parseInt(_0x1d7cb9(0x1cb))/0xa+parseInt(_0x1d7cb9(0x1c1))/0xb;if(_0xccd02e===_0x257c77)break;else _0x449fc9['push'](_0x449fc9['shift']());}catch(_0x1c96fa){_0x449fc9['push'](_0x449fc9['shift']());}}}(_0x4942,0x82f29));function _0x4942(){var _0x5caacf=['3701956PryAnz','5PsNNsk','normal','app_store','2022-09-28T06:06:06Z','3568810WlrZEx','4566045zlHzji','2022-09-28T06:06:08Z','entitlements','subscriptions','76718funmCL','9rNMlau','12LoiiEV','PURCHASED','1570281DpmGGC','subscriber','9924110KaCynA','14vIHkLY','parse','2267832MMljPM'];_0x4942=function(){return _0x5caacf;};return _0x4942();}function _0x3e31(_0x3d433a,_0x253578){var _0x49429f=_0x4942();return _0x3e31=function(_0x3e31ca,_0x339111){_0x3e31ca=_0x3e31ca-0x1ba;var _0x10c95f=_0x49429f[_0x3e31ca];return _0x10c95f;},_0x3e31(_0x3d433a,_0x253578);}var body=$response['body'],objc=JSON[_0x4fec3a(0x1cd)](body);objc[_0x4fec3a(0x1ca)][_0x4fec3a(0x1c3)]={'co.bergen.Darkroom.entitlement.allToolsAndFilters':{'expires_date':null,'grace_period_expires_date':null,'product_identifier':'co.bergen.Darkroom.product.forever.everything','purchase_date':_0x4fec3a(0x1bf)},'co.bergen.Darkroom.entitlement.selectiveAdjustments':{'expires_date':null,'grace_period_expires_date':null,'product_identifier':'co.bergen.Darkroom.product.forever.everything','purchase_date':'2022-09-28T06:06:06Z'}},objc[_0x4fec3a(0x1ca)][_0x4fec3a(0x1c4)]={'co.bergen.Darkroom.product.forever.everything':{'billing_issues_detected_at':null,'expires_date':null,'grace_period_expires_date':null,'is_sandbox':![],'original_purchase_date':_0x4fec3a(0x1c2),'ownership_type':_0x4fec3a(0x1c8),'period_type':_0x4fec3a(0x1bd),'purchase_date':_0x4fec3a(0x1bf),'store':_0x4fec3a(0x1be),'unsubscribe_detected_at':null}},$done({'body':JSON['stringify'](objc)});
