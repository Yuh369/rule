/******************************

脚本功能：MallocVPN解锁永久订阅
软件版本：1.0.11
下载地址：http://t.cn/A6KXZK5k
脚本作者：Passer_by_yun
更新时间：2022-12-06
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > MallocVPN解锁永久订阅
^https?:\/\/api\.revenuecat\.com\/v1\/(receipts|subscribers\/.{36})$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/MallocVPNProCrack.js

[mitm] 
hostname = api.revenuecat.com

*******************************/

function _0x51a8(){var _0x123823=['2022-11-01T03:25:42Z','parse','18129JjWnkV','app_store','37860ldgpoQ','8431168flYyou','2022-11-01T03:24:38Z','203827UekkMa','2jBRger','20939220dyCBfQ','50vjCRkf','1538757NJeNVx','340mDaEyA','Passer_by_yun','2013-08-01T07:00:00Z','stringify','1.0','1691144rCuPyr','8F867DB3-84A6-4D35-B03E-E260B6E31C9E'];_0x51a8=function(){return _0x123823;};return _0x51a8();}function _0x27a8(_0x105d9a,_0x4443cf){var _0x51a865=_0x51a8();return _0x27a8=function(_0x27a82f,_0xce8862){_0x27a82f=_0x27a82f-0xe7;var _0x21b03b=_0x51a865[_0x27a82f];return _0x21b03b;},_0x27a8(_0x105d9a,_0x4443cf);}var _0x52915f=_0x27a8;(function(_0x28828a,_0x1e2f62){var _0x4f976c=_0x27a8,_0x5d1d22=_0x28828a();while(!![]){try{var _0x380db1=parseInt(_0x4f976c(0xec))/0x1*(-parseInt(_0x4f976c(0xed))/0x2)+-parseInt(_0x4f976c(0xe7))/0x3*(parseInt(_0x4f976c(0xf1))/0x4)+parseInt(_0x4f976c(0xef))/0x5*(-parseInt(_0x4f976c(0xe9))/0x6)+parseInt(_0x4f976c(0xf6))/0x7+-parseInt(_0x4f976c(0xea))/0x8+parseInt(_0x4f976c(0xf0))/0x9+parseInt(_0x4f976c(0xee))/0xa;if(_0x380db1===_0x1e2f62)break;else _0x5d1d22['push'](_0x5d1d22['shift']());}catch(_0xc3f4c9){_0x5d1d22['push'](_0x5d1d22['shift']());}}}(_0x51a8,0xa4109));var body=$response['body'],obj=JSON[_0x52915f(0xf9)](body);obj={'request_date_ms':0x184313b731e,'request_date':'2022-11-01T03:28:10Z','subscriber':{'non_subscriptions':{'malloc_vpn_one_off':[{'id':_0x52915f(0xf2),'is_sandbox':!![],'purchase_date':'2022-11-01T03:25:42Z','original_purchase_date':_0x52915f(0xf8),'store':_0x52915f(0xe8)}]},'first_seen':_0x52915f(0xeb),'original_application_version':_0x52915f(0xf5),'other_purchases':{'malloc_vpn_one_off':{'purchase_date':'2022-11-01T03:25:42Z'}},'management_url':null,'subscriptions':{},'entitlements':{'IOS_PRO':{'grace_period_expires_date':null,'purchase_date':'2022-11-01T03:25:42Z','product_identifier':'malloc_vpn_one_off','expires_date':null}},'original_purchase_date':_0x52915f(0xf3),'original_app_user_id':_0x52915f(0xf7),'last_seen':_0x52915f(0xeb)}},body=JSON[_0x52915f(0xf4)](obj),$done({'body':body});
