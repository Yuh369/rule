/******************************

脚本功能：Art Widget 解锁永久会员
软件版本：1.4.7
下载地址：http://t.cn/A6C0rsOk
脚本作者：Hausd0rff
更新时间：2023-03-12
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > Art Widget 解锁永久会员
^https?:\/\/www\.40sishi\.com\/artwidget\/user\/profile$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/ArtWidgetVipCrack.js

[mitm] 
hostname = www.40sishi.com

*******************************/

var _0x5d067d=_0x3345;(function(_0x44c72f,_0x4fc812){var _0x55285b=_0x3345,_0x46e937=_0x44c72f();while(!![]){try{var _0x227d38=parseInt(_0x55285b(0x105))/0x1*(-parseInt(_0x55285b(0x112))/0x2)+-parseInt(_0x55285b(0x114))/0x3*(-parseInt(_0x55285b(0x106))/0x4)+-parseInt(_0x55285b(0x10c))/0x5*(-parseInt(_0x55285b(0x107))/0x6)+-parseInt(_0x55285b(0x10a))/0x7+-parseInt(_0x55285b(0x10e))/0x8*(-parseInt(_0x55285b(0x109))/0x9)+parseInt(_0x55285b(0x111))/0xa*(-parseInt(_0x55285b(0x108))/0xb)+parseInt(_0x55285b(0x10f))/0xc;if(_0x227d38===_0x4fc812)break;else _0x46e937['push'](_0x46e937['shift']());}catch(_0x11c181){_0x46e937['push'](_0x46e937['shift']());}}}(_0x3e4e,0x44096));var objc=JSON['parse']($response[_0x5d067d(0x10d)]);function _0x3345(_0x116e71,_0xe17eeb){var _0x3e4ea7=_0x3e4e();return _0x3345=function(_0x3345f1,_0x5a5ed7){_0x3345f1=_0x3345f1-0x105;var _0x421409=_0x3e4ea7[_0x3345f1];return _0x421409;},_0x3345(_0x116e71,_0xe17eeb);}objc[_0x5d067d(0x110)][_0x5d067d(0x10b)]={'state':0x1,'forever':!![],'startTime':0x6384daff,'expireTime':0x79132d9ff},$done({'body':JSON[_0x5d067d(0x113)](objc)});function _0x3e4e(){var _0x2262b4=['4hDgnEv','1986VmfOao','11TDXlXn','284409cVtMwn','3088659kYFJWd','vipState','7510IWaNta','body','16WqJuMm','5598732uDPHeD','data','869810RqTsUQ','1510OrLRWJ','stringify','384078rYIQTC','461sXyZZF'];_0x3e4e=function(){return _0x2262b4;};return _0x3e4e();}
