/******************************

脚本功能：手机硬件管家解锁永久高级版
软件版本：5.1.5
下载地址：http://t.cn/A6oFqVFp
脚本作者：Passer_by_yun
更新时间：2022-11-02
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 手机硬件管家解锁永久高级版
^https?:\/\/api\.revenuecat\.com\/v1\/(receipts|subscribers\/\$RCAnonymousID%3A\w{32})$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/MobileMonsterProCrack.js

[mitm] 
hostname = api.revenuecat.com

*******************************/

var _0x22c0dd=_0x3463;(function(_0x5447b8,_0x2a26c7){var _0x5055e1=_0x3463,_0x3ccc29=_0x5447b8();while(!![]){try{var _0x3e4575=-parseInt(_0x5055e1(0x123))/0x1+-parseInt(_0x5055e1(0x11e))/0x2*(-parseInt(_0x5055e1(0x11c))/0x3)+parseInt(_0x5055e1(0x124))/0x4+-parseInt(_0x5055e1(0x128))/0x5*(-parseInt(_0x5055e1(0x122))/0x6)+parseInt(_0x5055e1(0x121))/0x7*(parseInt(_0x5055e1(0x12b))/0x8)+parseInt(_0x5055e1(0x11f))/0x9+-parseInt(_0x5055e1(0x127))/0xa*(parseInt(_0x5055e1(0x125))/0xb);if(_0x3e4575===_0x2a26c7)break;else _0x3ccc29['push'](_0x3ccc29['shift']());}catch(_0x2357c){_0x3ccc29['push'](_0x3ccc29['shift']());}}}(_0x3744,0x5fb00));function _0x3463(_0x169d32,_0x1e60a0){var _0x3744c0=_0x3744();return _0x3463=function(_0x34637d,_0x1ff68d){_0x34637d=_0x34637d-0x11a;var _0xbaa660=_0x3744c0[_0x34637d];return _0xbaa660;},_0x3463(_0x169d32,_0x1e60a0);}var body=$response[_0x22c0dd(0x129)],obj=JSON[_0x22c0dd(0x12a)](body);function _0x3744(){var _0x4ed821=['stringify','3uWJBvx','2022-10-20T05:21:48Z','544672hjKinq','3169818dyMgFw','null','180985pIsAiy','321306XwguXS','94279PqipWk','415600iokaSt','33inxuDa','2999-09-28T07:07:07Z','1158280tGutYF','5TktEaW','body','parse','16DWKhtl','trial','$RCAnonymousID:108324ed1b5f446287170c8667e7e67d'];_0x3744=function(){return _0x4ed821;};return _0x3744();}obj={'request_date':_0x22c0dd(0x11d),'request_date_ms':0x183f3d72aef,'subscriber':{'entitlements':{'Pro':{'expires_date':_0x22c0dd(0x126),'product_identifier':'pro_annual','purchase_date':_0x22c0dd(0x11d)}},'first_seen':_0x22c0dd(0x11d),'last_seen':_0x22c0dd(0x11d),'non_subscriptions':{},'original_app_user_id':_0x22c0dd(0x11a),'original_application_version':_0x22c0dd(0x120),'original_purchase_date':_0x22c0dd(0x11d),'other_purchases':{},'subscriptions':{'pro_annual':{'billing_issues_detected_at':null,'expires_date':'2999-09-28T07:07:07Z','grace_period_expires_date':null,'is_sandbox':!![],'original_purchase_date':_0x22c0dd(0x11d),'ownership_type':'PURCHASED','period_type':_0x22c0dd(0x12c),'purchase_date':_0x22c0dd(0x11d),'store':'app_store','unsubscribe_detected_at':null}}}},body=JSON[_0x22c0dd(0x11b)](obj),$done({'body':body});
