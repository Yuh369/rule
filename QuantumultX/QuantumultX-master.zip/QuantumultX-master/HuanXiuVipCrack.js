/******************************

脚本功能：幻休解锁永久会员
软件版本：2.4.1
下载地址：http://t.cn/A6Chv2d5
脚本作者：Hausd0rff
更新时间：2023-02-09
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 幻休解锁永久会员
^https?:\/\/api\.shaolinzen\.com\/user\/v1\/info$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/HuanXiuVipCrack.js

[mitm] 
hostname = api.shaolinzen.com

*******************************/

var _0x55b1db=_0x5c0e;(function(_0x254005,_0x1f028c){var _0x1d8d12=_0x5c0e,_0x10dd55=_0x254005();while(!![]){try{var _0x35c3d2=-parseInt(_0x1d8d12(0x163))/0x1+-parseInt(_0x1d8d12(0x161))/0x2+parseInt(_0x1d8d12(0x15d))/0x3+-parseInt(_0x1d8d12(0x168))/0x4+-parseInt(_0x1d8d12(0x15f))/0x5+-parseInt(_0x1d8d12(0x165))/0x6*(parseInt(_0x1d8d12(0x160))/0x7)+parseInt(_0x1d8d12(0x166))/0x8;if(_0x35c3d2===_0x1f028c)break;else _0x10dd55['push'](_0x10dd55['shift']());}catch(_0x52738d){_0x10dd55['push'](_0x10dd55['shift']());}}}(_0x3796,0x862d5));function _0x5c0e(_0x403db3,_0x500b6c){var _0x379659=_0x3796();return _0x5c0e=function(_0x5c0ef6,_0x46f453){_0x5c0ef6=_0x5c0ef6-0x15c;var _0x406c75=_0x379659[_0x5c0ef6];return _0x406c75;},_0x5c0e(_0x403db3,_0x500b6c);}var body=$response[_0x55b1db(0x169)],objc=JSON[_0x55b1db(0x15e)](body);function _0x3796(){var _0x10b2a0=['544711OFPQyn','2999-09-28','84NQapgR','24065656uNUzeg','stringify','7176YVseoU','body','data','933951viCNZQ','parse','3223040bjBxeC','482832itkDmE','1226316RiYIKD','vipExpireTime'];_0x3796=function(){return _0x10b2a0;};return _0x3796();}objc[_0x55b1db(0x15c)]['vipActive']=0x1,objc[_0x55b1db(0x15c)][_0x55b1db(0x162)]=_0x55b1db(0x164),$done({'body':JSON[_0x55b1db(0x167)](objc)});
