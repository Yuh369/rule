/******************************

脚本功能：PornHub Unlock Premium
网页版本：2.0.1
网站地址：https://shrtm.nu/PornHub
脚本作者：Hausd0rff
更新时间：2022-03-09
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️此脚本仅供学习与交流，
        请勿转载与贩卖！⚠️⚠️⚠️
*******************************
[rewrite_local]
# > PornHub Unlock Premium By Hausd0rff
^https?:\/\/cn\.pornhubpremium\.com\/ url script-request-header https://raw.githubusercontent.com/yqc007/QuantumultX/master/PornHubPremiumCrack.js

[mitm] 
hostname = cn.pornhubpremium.com

*******************************/

var encode_version = '_0xnb0666',
    zgxjl = '__0xdb04d',
    __0xdb04d = ['wqsmcAlrwpLDn8KAwq/CvUouNMKRBsOMwrB8wo4Kw6jCi2/CgwvCmcOcwrrCnC3DrVPCgcK2w7hpYADCrsO1O8OXwoTClAnDhA3DlkBpw7ZWwrDCrMKoUMOOwoJ+wpTCm1LCv8Kaw6NAw4d/wpc+N8OrPMOrXcOywoxTLMOEw50ewqrCukB8MsKKKSfDnMOMw5/CmSzDiMOkw4AOKSdtwpLDqghSwoZswpfDmcKweMKHViHCiGUgw4FdeUnDq8KvaFDCrF8kC17DrxrDrUo4HcKNwpNHYibDisKZw6XCu3dlGWtVwpVGw6DDlcK9wrfCnxVqwo0hMcK6wokKw4Qbwrcxw7bDoMOHYi9Be8OGwqg/ZsOew4HCo0c/w7BvDAl6Pm1vaDfCoVlbUsKfQsKyw7ZAw4zDmMOjNmjCi20ww5gHwpHDusOIw4t7w6XDo8KFw6YJKsKKw6ZmPMOcw5MUwq9IwobCsWopwoPDsxrDlsOIP8K9w75BKgLCvTzCsTYbPcOuXsKEFMOKw5jDrcOew5TDtwTDumZfwonDpR1Ww5jDkcK+PGXCgMOEwoIlLzTDgCZPCcOpdAc9Q2TCv8Oqw4zDuDNTw7PDtTvCgGXCg8KrUMOoXUTCo8Oqw4rChMKawokVPcKTw4xqw7lQwq4yw78swrtAwp5Ewr4MAMOpXMOVw7g7GSVNwr/CklDDnkF0wrjDlcOfOCnChjjCulQkNAHCiRfDoMKkTigkXcOfwqtLwoLDtsO6JVpeIsOpw47DjcOew73DkMK2V2LChFHDlMOvTsO5UgwKfCAPwrnCmsKXMXfDqCnCg1A8SMKiw6DDhMK9Z8KbHsKnw5BXwrcUXcOHVl3DrCEbwonDscKuYcKjwo/Dm8OWwpJEwoRJSmhwwoYFDMOSMXbDi8OCw7TCgcKQw6wLQ8Ktw4nDm3nChcKuwp46wohXwqXDo1bClwbDlX/CojrCvcKPwpjCsRzCp8Ogw5LChSslO8OIw7nDownDkMOfU3LCgMO3w6bDjynCt8K8wp5qZsKxwqbDlsOuwqbDhE3CjxYxGX1TA37CrxsXw6cKwpBOwqgDw43Ci8OUwoPCsMOVbDzDuBfCksKzw5HDqMOSw6rDrV8Lw59WwozDq8O5NnY2w5o8wqNKAmDDjcO9b3fDoMOPwprCj3/DssKywqrCvsKPwrfCpCZgwrodK3DDsMKkw4Y9w4PCr8O/XsOaw7Z2w6wpwowUwpnDncKSa8KmLsKww4HCrA0ubsK0wp3Cqn4Yw53DjcO3P3vClMKAw60pcUt2I13CjcKUKg==', 'DFLDo8O+P8KVw6VpwqEt', 'wqrDicKM', 'IjvCvgMmwocjJFHCjcK/wps+DA==', '54qU5pyY5Y2377+ewopi5LyL5a+m5p6W5byX56iv77yO6L2+6K2N5pSh5oyF5oid5LqF55q75baf5Ly4', '5Yms6Zqm54uB5pye5YyB77+Rw47CiuS/vOWuguafiOW8ueeqhw==', 'w5HDr8OFZBE=', 'wqLCn8KMNsKH', 'fsObwoEuw4E=', 'w4fDp8OvVj4=', 'wozDlsK0dsK6', 'X8OXwos5w4PCksKn', 'wooyw5rChxhxwqIjwqURw40sWw==', 'XsOWwo8zw5LCicKyw4FLw7Q9PcOmPMO4KMKJw7A9fsKoW8OHQsKZHsK9woTCi8KHfn1kE8Odb8KPwrvCiMKuTSrDt8K1'];
(function(_0x21bd29, _0x4a0b00) {
    var _0x47cad6 = function(_0x132e93) {
        while (--_0x132e93) {
            _0x21bd29['push'](_0x21bd29['shift']());
        }
    };
    _0x47cad6(++_0x4a0b00);
}(__0xdb04d, 0x123));
var _0x56ae = function(_0x1a1e26, _0x260017) {
    _0x1a1e26 = _0x1a1e26 - 0x0;
    var _0x4b0a66 = __0xdb04d[_0x1a1e26];
    if (_0x56ae['initialized'] === undefined) {
        (function() {
            var _0x4f9051 = typeof window !== 'undefined' ? window : typeof process === 'object' && typeof require === 'function' && typeof global === 'object' ? global : this;
            var _0x2368f3 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            _0x4f9051['atob'] || (_0x4f9051['atob'] = function(_0x3681f7) {
                var _0x3d1110 = String(_0x3681f7)['replace'](/=+$/, '');
                for (var _0x1194d7 = 0x0, _0x4333c9, _0x32d92f, _0x12cbe9 = 0x0, _0x498389 = ''; _0x32d92f = _0x3d1110['charAt'](_0x12cbe9++); ~_0x32d92f && (_0x4333c9 = _0x1194d7 % 0x4 ? _0x4333c9 * 0x40 + _0x32d92f : _0x32d92f, _0x1194d7++ % 0x4) ? _0x498389 += String['fromCharCode'](0xff & _0x4333c9 >> (-0x2 * _0x1194d7 & 0x6)) : 0x0) {
                    _0x32d92f = _0x2368f3['indexOf'](_0x32d92f);
                }
                return _0x498389;
            });
        }());
        var _0x59c7a9 = function(_0x5e17ef, _0x25ddbb) {
            var _0x11590d = [],
                _0x4a9e68 = 0x0,
                _0x105834, _0x34dbb5 = '',
                _0x5634c3 = '';
            _0x5e17ef = atob(_0x5e17ef);
            for (var _0x4a90cb = 0x0, _0x84157b = _0x5e17ef['length']; _0x4a90cb < _0x84157b; _0x4a90cb++) {
                _0x5634c3 += '%' + ('00' + _0x5e17ef['charCodeAt'](_0x4a90cb)['toString'](0x10))['slice'](-0x2);
            }
            _0x5e17ef = decodeURIComponent(_0x5634c3);
            for (var _0x349d53 = 0x0; _0x349d53 < 0x100; _0x349d53++) {
                _0x11590d[_0x349d53] = _0x349d53;
            }
            for (_0x349d53 = 0x0; _0x349d53 < 0x100; _0x349d53++) {
                _0x4a9e68 = (_0x4a9e68 + _0x11590d[_0x349d53] + _0x25ddbb['charCodeAt'](_0x349d53 % _0x25ddbb['length'])) % 0x100;
                _0x105834 = _0x11590d[_0x349d53];
                _0x11590d[_0x349d53] = _0x11590d[_0x4a9e68];
                _0x11590d[_0x4a9e68] = _0x105834;
            }
            _0x349d53 = 0x0;
            _0x4a9e68 = 0x0;
            for (var _0x1ac8c7 = 0x0; _0x1ac8c7 < _0x5e17ef['length']; _0x1ac8c7++) {
                _0x349d53 = (_0x349d53 + 0x1) % 0x100;
                _0x4a9e68 = (_0x4a9e68 + _0x11590d[_0x349d53]) % 0x100;
                _0x105834 = _0x11590d[_0x349d53];
                _0x11590d[_0x349d53] = _0x11590d[_0x4a9e68];
                _0x11590d[_0x4a9e68] = _0x105834;
                _0x34dbb5 += String['fromCharCode'](_0x5e17ef['charCodeAt'](_0x1ac8c7) ^ _0x11590d[(_0x11590d[_0x349d53] + _0x11590d[_0x4a9e68]) % 0x100]);
            }
            return _0x34dbb5;
        };
        _0x56ae['rc4'] = _0x59c7a9;
        _0x56ae['data'] = {};
        _0x56ae['initialized'] = !![];
    }
    var _0x4394b2 = _0x56ae['data'][_0x1a1e26];
    if (_0x4394b2 === undefined) {
        if (_0x56ae['once'] === undefined) {
            _0x56ae['once'] = !![];
        }
        _0x4b0a66 = _0x56ae['rc4'](_0x4b0a66, _0x260017);
        _0x56ae['data'][_0x1a1e26] = _0x4b0a66;
    } else {
        _0x4b0a66 = _0x4394b2;
    }
    return _0x4b0a66;
};
var _0xnb0666 = $request[_0x56ae('0x0', 'aX!j')];
_0xnb0666[_0x56ae('0x1', '1!vt')] = _0x56ae('0x2', 'aX!j');
_0xnb0666['\x43\x6f\x6f\x6b\x69\x65'] = _0x56ae('0x3', '#7EQ');
_0xnb0666[_0x56ae('0x4', 'JbIw')] = 'Mozilla/5.0\x20(iPhone;\x20CPU\x20iPhone\x20OS\x2012_4\x20like\x20Mac\x20OS\x20X)\x20AppleWebKit/605.1.15\x20(KHTML,\x20like\x20Gecko)\x20Version/12.1.2\x20Mobile/15E148\x20Safari/604.1';
$done({
    '\x68\x65\x61\x64\x65\x72\x73' : _0xnb0666
});
(function(_0x15b200, _0x40e7a3, _0x1843b2) {
    var _0x824a4f = {
        'gLHEh': _0x56ae('0x5', '#IL['),
        'fvynj': function _0x296f41(_0x2e8759, _0x1dbde2) {
            return _0x2e8759 !== _0x1dbde2;
        },
        'lDhaq': 'undefined',
        'lGuXU': function _0x426950(_0x5d1e0e, _0x2407f9) {
            return _0x5d1e0e === _0x2407f9;
        },
        'FwUKf': _0x56ae('0x6', 'LM^g'),
        'Iiksg': function _0x33bdb7(_0x25ce3a, _0x5180f1) {
            return _0x25ce3a + _0x5180f1;
        },
        'qDbwG': _0x56ae('0x7', 'Ecf['),
        'kHiZH': _0x56ae('0x8', 'VDFT')
    };
    _0x1843b2 = 'al';
    try {
        _0x1843b2 += _0x824a4f[_0x56ae('0x9', '0I]!')];
        _0x40e7a3 = encode_version;
        if (!(_0x824a4f[_0x56ae('0xa', 'kBhG')](typeof _0x40e7a3, _0x824a4f['lDhaq']) && _0x824a4f['lGuXU'](_0x40e7a3, _0x824a4f['FwUKf']))) {
            _0x15b200[_0x1843b2](_0x824a4f[_0x56ae('0xb', 'aX!j')](_0x824a4f[_0x56ae('0xc', '0I]!')]));
        }
    } catch (_0x567193) {
        _0x15b200[_0x1843b2](_0x824a4f[_0x56ae('0xd', '$E^e')]);
    }
});
