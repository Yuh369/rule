/******************************

脚本功能：NotePlan3解锁永久订阅
软件版本：3.7.1
下载地址：http://t.cn/A6KZMlGb
脚本作者：Passer_by_yun
更新时间：2022-11-09
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > NotePlan3解锁永久订阅
^https?:\/\/api\.revenuecat\.com\/v1\/(receipts|subscribers\/\$RCAnonymousID%3A\w{32})$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/NotePlan3ProCrack.js

[mitm] 
hostname = api.revenuecat.com

*******************************/

var _0x247f0d=_0x1b81;function _0x1c95(){var _0x238b14=['2730938oZImcG','https://apps.apple.com/account/subscriptions','trial','stringify','309396hQWynC','1205688gfTNEw','157939nwGkPW','2500398YpmBKs','2022-11-13T16:51:54Z','2022-11-13T16:51:51Z','app_store','75872bJZmVQ','Passer_by_yun','body','parse','2022-11-13T16:52:14Z','20wFPHFR','2013-08-01T07:00:00Z','2OcfmMs','2253990lzIlql','co.noteplan.subscription.personal.annual','2022-11-13T16:49:55Z','2999-09-28T00:00:00Z','PURCHASED'];_0x1c95=function(){return _0x238b14;};return _0x1c95();}function _0x1b81(_0x15f3df,_0x2ae620){var _0x1c95b9=_0x1c95();return _0x1b81=function(_0x1b81e6,_0x4fc351){_0x1b81e6=_0x1b81e6-0x1a6;var _0xe8167=_0x1c95b9[_0x1b81e6];return _0xe8167;},_0x1b81(_0x15f3df,_0x2ae620);}(function(_0xa150b7,_0x457249){var _0x26f80d=_0x1b81,_0x6681b3=_0xa150b7();while(!![]){try{var _0x45aa5a=parseInt(_0x26f80d(0x1b9))/0x1+parseInt(_0x26f80d(0x1ad))/0x2*(parseInt(_0x26f80d(0x1b7))/0x3)+-parseInt(_0x26f80d(0x1a6))/0x4*(-parseInt(_0x26f80d(0x1ab))/0x5)+parseInt(_0x26f80d(0x1ae))/0x6+-parseInt(_0x26f80d(0x1b3))/0x7+parseInt(_0x26f80d(0x1b8))/0x8+-parseInt(_0x26f80d(0x1ba))/0x9;if(_0x45aa5a===_0x457249)break;else _0x6681b3['push'](_0x6681b3['shift']());}catch(_0x267fdc){_0x6681b3['push'](_0x6681b3['shift']());}}}(_0x1c95,0x2fb23));var body=$response[_0x247f0d(0x1a8)],obj=JSON[_0x247f0d(0x1a9)](body);obj={'request_date_ms':0x18471e7e72d,'request_date':_0x247f0d(0x1aa),'subscriber':{'non_subscriptions':{},'first_seen':'2022-11-13T16:49:55Z','original_application_version':'1.0','other_purchases':{},'management_url':_0x247f0d(0x1b4),'subscriptions':{'co.noteplan.subscription.personal.annual':{'original_purchase_date':_0x247f0d(0x1bb),'expires_date':_0x247f0d(0x1b1),'is_sandbox':!![],'refunded_at':null,'unsubscribe_detected_at':null,'grace_period_expires_date':null,'period_type':_0x247f0d(0x1b5),'purchase_date':_0x247f0d(0x1bc),'billing_issues_detected_at':null,'ownership_type':_0x247f0d(0x1b2),'store':_0x247f0d(0x1bd),'auto_resume_date':null}},'entitlements':{'Personal\x20Annual':{'grace_period_expires_date':null,'purchase_date':'2022-11-13T16:51:51Z','product_identifier':_0x247f0d(0x1af),'expires_date':_0x247f0d(0x1b1)}},'original_purchase_date':_0x247f0d(0x1ac),'original_app_user_id':_0x247f0d(0x1a7),'last_seen':_0x247f0d(0x1b0)}},body=JSON[_0x247f0d(0x1b6)](obj),$done({'body':body});
