/******************************

脚本功能：小明计算器解锁永久会员
软件版本：2.1
下载地址：http://t.cn/A69e0ori
脚本作者：Hausd0rff
更新时间：2023-02-07
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 小明计算器解锁永久会员
^https?:\/\/jsq\.mingcalc\.cn\/XMGetMeCount\.ashx$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/XMCalculatorVipCrack.js

[mitm] 
hostname = jsq.mingcalc.cn

*******************************/

var _0xdcaafd=_0x2e34;function _0x24e4(){var _0x258b2f=['stringify','831082IuXNYT','2056896YOBIjX','2999-09-28\x2009:09:09','2103560jAuXaU','6145GNCXlS','Hausd0rff\x20Crack','252TIUVWr','7LUqFlq','264483HXzcbd','1197119rCcvfK','1wUvcNX','9b39f08795095eff84f4fd4792e3f1e9','64503nqfUId','130AidWoY'];_0x24e4=function(){return _0x258b2f;};return _0x24e4();}function _0x2e34(_0x41f3f7,_0x1295b7){var _0x24e48b=_0x24e4();return _0x2e34=function(_0x2e34d4,_0x4b3ea9){_0x2e34d4=_0x2e34d4-0x1bc;var _0x3e6d16=_0x24e48b[_0x2e34d4];return _0x3e6d16;},_0x2e34(_0x41f3f7,_0x1295b7);}(function(_0x219f53,_0x3e8e3d){var _0x4f5222=_0x2e34,_0xfc2f57=_0x219f53();while(!![]){try{var _0x4744bc=parseInt(_0x4f5222(0x1c9))/0x1*(-parseInt(_0x4f5222(0x1bf))/0x2)+parseInt(_0x4f5222(0x1c7))/0x3+parseInt(_0x4f5222(0x1c5))/0x4*(-parseInt(_0x4f5222(0x1c3))/0x5)+parseInt(_0x4f5222(0x1c0))/0x6+-parseInt(_0x4f5222(0x1c6))/0x7*(-parseInt(_0x4f5222(0x1c2))/0x8)+parseInt(_0x4f5222(0x1bc))/0x9*(parseInt(_0x4f5222(0x1bd))/0xa)+parseInt(_0x4f5222(0x1c8))/0xb;if(_0x4744bc===_0x3e8e3d)break;else _0xfc2f57['push'](_0xfc2f57['shift']());}catch(_0x214faf){_0xfc2f57['push'](_0xfc2f57['shift']());}}}(_0x24e4,0x6260a),$done({'body':JSON[_0xdcaafd(0x1be)]({'code':0x1,'des':'','result':{'VipEnd':_0xdcaafd(0x1c1),'VipEndDes':_0xdcaafd(0x1c4),'Token':_0xdcaafd(0x1ca)}})}));
