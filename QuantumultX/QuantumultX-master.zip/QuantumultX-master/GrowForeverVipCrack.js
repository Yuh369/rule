/******************************

脚本功能：Grow解锁永久会员
软件版本：1.7.9
下载地址：http://t.cn/A6ILzuhD
脚本作者：Passer_by_yun
更新时间：2022-10-20
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > Grow解锁永久会员
^https?:\/\/api\.revenuecat\.com\/v1\/(receipts|subscribers\/\$RCAnonymousID%3A\w{32})$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/GrowForeverVipCrack.js

[mitm] 
hostname = api.revenuecat.com

*******************************/

function _0x2d7e(_0x1710d5,_0x43bb16){var _0x135a46=_0x135a();return _0x2d7e=function(_0x2d7e21,_0x3e9d0f){_0x2d7e21=_0x2d7e21-0xac;var _0x5d371c=_0x135a46[_0x2d7e21];return _0x5d371c;},_0x2d7e(_0x1710d5,_0x43bb16);}var _0x25cfa8=_0x2d7e;(function(_0x3b68b3,_0x203bf9){var _0x4442ec=_0x2d7e,_0x429e98=_0x3b68b3();while(!![]){try{var _0x3e9bf3=-parseInt(_0x4442ec(0xb9))/0x1+parseInt(_0x4442ec(0xb2))/0x2+-parseInt(_0x4442ec(0xb3))/0x3*(parseInt(_0x4442ec(0xb0))/0x4)+parseInt(_0x4442ec(0xb4))/0x5*(-parseInt(_0x4442ec(0xb7))/0x6)+-parseInt(_0x4442ec(0xad))/0x7+parseInt(_0x4442ec(0xae))/0x8+parseInt(_0x4442ec(0xb8))/0x9;if(_0x3e9bf3===_0x203bf9)break;else _0x429e98['push'](_0x429e98['shift']());}catch(_0x5204cf){_0x429e98['push'](_0x429e98['shift']());}}}(_0x135a,0x6a8ed));var body=$response[_0x25cfa8(0xbb)],obj=JSON[_0x25cfa8(0xb6)](body);function _0x135a(){var _0x43376e=['app_store','2259932deHgdi','stringify','1667468pUHbEd','3kpGOya','1568980XwIidu','PURCHASED','parse','6KMzneM','8173215GUuULQ','340385Xktvfu','$RCAnonymousID:Passer_by_yun','body','grow_lifetime','2022-10-20T05:21:48Z','1383053WTKfET','890680TMPvhE'];_0x135a=function(){return _0x43376e;};return _0x135a();}obj={'request_date':_0x25cfa8(0xac),'subscriber':{'last_seen':_0x25cfa8(0xac),'first_seen':_0x25cfa8(0xac),'original_application_version':'null','other_purchases':{},'management_url':'itms-apps://apps.apple.com/account/subscriptions','subscriptions':{'grow_lifetime':{'is_sandbox':![],'ownership_type':_0x25cfa8(0xb5),'billing_issues_detected_at':null,'period_type':'normal','expires_date':null,'grace_period_expires_date':null,'unsubscribe_detected_at':null,'original_purchase_date':_0x25cfa8(0xac),'purchase_date':_0x25cfa8(0xac),'store':_0x25cfa8(0xaf)}},'entitlements':{'grow.pro':{'expires_date':null,'purchase_date':_0x25cfa8(0xac),'product_identifier':_0x25cfa8(0xbc)}},'original_purchase_date':_0x25cfa8(0xac),'original_app_user_id':_0x25cfa8(0xba),'non_subscriptions':{}}},body=JSON[_0x25cfa8(0xb1)](obj),$done({'body':body});
