# QuantumultX-Script

1⃣️ 脚本作者：Hausd0rff

2⃣️ 电报频道：https://t.me/yqc_123

3⃣️ 问题反馈：https://t.me/yqc_777

4⃣️ 引用说明：如需引用请注明出处👇
https://t.me/yqc_123 谢谢合作！

5⃣️ 项目声明：
开源JS脚本仅供学习交流🍟，欢迎stars🌟，禁止focks🈲️，否则你将被禁止🚫！禁止商业用途🈲️，否则后果自负👻！

Project Statement:
Open source JS scripts are only for learning and communication, welcome to collect, forbid copying, otherwise you will be banned! Commercial use is prohibited, otherwise you will bear all the consequences!
