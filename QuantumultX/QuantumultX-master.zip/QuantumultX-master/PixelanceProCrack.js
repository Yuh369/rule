/******************************

脚本功能：Pixelance解锁永久高级版
软件版本：1.6.1
下载地址：http://t.cn/A6KHgsr4
脚本作者：Hausd0rff
更新时间：2022-12-18
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > Pixelance解锁永久高级版
^https?:\/\/iap\.etm\.tech\/receipts$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/PixelanceProCrack.js

[mitm] 
hostname = iap.etm.tech

*******************************/

function _0x3ec3(){var _0x119f63=['6192hqzNkf','80340XuDQMp','70OAXZBD','570qjMNLq','body','909650DiFAtf','534159UWyQVF','1773051OXDuYV','6ZOpdnj','1884184ffPnsC','128098BAdfSs','Production','Photo_Enhancer_Premium_Yearly_20221212'];_0x3ec3=function(){return _0x119f63;};return _0x3ec3();}function _0x45c6(_0x432936,_0x5ee1e6){var _0x3ec39f=_0x3ec3();return _0x45c6=function(_0x45c678,_0x3751ef){_0x45c678=_0x45c678-0xcf;var _0x9a2d32=_0x3ec39f[_0x45c678];return _0x9a2d32;},_0x45c6(_0x432936,_0x5ee1e6);}var _0x1630e4=_0x45c6;(function(_0x42c43f,_0x55a602){var _0x1d9238=_0x45c6,_0x566e13=_0x42c43f();while(!![]){try{var _0x144e1a=-parseInt(_0x1d9238(0xdb))/0x1+parseInt(_0x1d9238(0xd7))/0x2+-parseInt(_0x1d9238(0xd0))/0x3*(-parseInt(_0x1d9238(0xda))/0x4)+-parseInt(_0x1d9238(0xd2))/0x5+parseInt(_0x1d9238(0xd5))/0x6*(parseInt(_0x1d9238(0xd4))/0x7)+parseInt(_0x1d9238(0xd6))/0x8+parseInt(_0x1d9238(0xd3))/0x9*(-parseInt(_0x1d9238(0xcf))/0xa);if(_0x144e1a===_0x55a602)break;else _0x566e13['push'](_0x566e13['shift']());}catch(_0x51544c){_0x566e13['push'](_0x566e13['shift']());}}}(_0x3ec3,0x2952a));var body=$response[_0x1630e4(0xd1)],objc=JSON['parse'](body);objc={'entitlements':[{'redeem':{},'expires_date_ms':0x1d8df1500b08,'purchase_date_ms':0x174d2393a80,'product_identifier':_0x1630e4(0xd9),'is_in_intro_offer_period':![],'environment':_0x1630e4(0xd8),'auto_renew':![],'is_in_trial_period':![],'entitlement_id':'premium'}],'is_valid':!![]},body=JSON['stringify'](objc),$done({'body':body});
