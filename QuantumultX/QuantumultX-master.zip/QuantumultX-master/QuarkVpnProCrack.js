/******************************

脚本功能：QuarkVPN 解锁永久订阅
软件版本：1.4.2
下载地址：http://t.cn/A6KNbOee
脚本作者：Passer_by_yun
更新时间：2022-11-28
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > QuarkVPN 解锁永久订阅
^https?:\/\/.*api\.italianbooray\.com\/Api\/getAccountInfo$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/QuarkVpnProCrack.js

[mitm] 
hostname = *api.italianbooray.com

*******************************/

function _0xa3d7(){var _0x4b2fde=['16090SvVrve','is_vip\x22:1','10288OuOeSW','hide_full_ad\x22:1','1300iSSAkl','853188iBhPAT','744298mXjizX','609207cZLtAu','end_expire_time\x22:3392814600000','replace','3dZEpYa','3696LAhXxo','2582460VTUVTu','1196QFhwYp','sub_status\x22:1','3852TgukLd','33nKsdUP'];_0xa3d7=function(){return _0x4b2fde;};return _0xa3d7();}var _0x5b8223=_0x19ec;function _0x19ec(_0x268347,_0x1bad0a){var _0xa3d70e=_0xa3d7();return _0x19ec=function(_0x19ec0f,_0x3cff9c){_0x19ec0f=_0x19ec0f-0x108;var _0x2e151f=_0xa3d70e[_0x19ec0f];return _0x2e151f;},_0x19ec(_0x268347,_0x1bad0a);}(function(_0x75b001,_0x460db8){var _0x367209=_0x19ec,_0x26f9e0=_0x75b001();while(!![]){try{var _0x40795a=-parseInt(_0x367209(0x10a))/0x1+parseInt(_0x367209(0x109))/0x2*(-parseInt(_0x367209(0x10d))/0x3)+parseInt(_0x367209(0x110))/0x4*(-parseInt(_0x367209(0x118))/0x5)+-parseInt(_0x367209(0x108))/0x6+parseInt(_0x367209(0x10e))/0x7*(parseInt(_0x367209(0x116))/0x8)+parseInt(_0x367209(0x112))/0x9*(parseInt(_0x367209(0x114))/0xa)+parseInt(_0x367209(0x113))/0xb*(parseInt(_0x367209(0x10f))/0xc);if(_0x40795a===_0x460db8)break;else _0x26f9e0['push'](_0x26f9e0['shift']());}catch(_0x249ec6){_0x26f9e0['push'](_0x26f9e0['shift']());}}}(_0xa3d7,0xc63cd),body=$response['body'][_0x5b8223(0x10c)](/is_vip":\d/g,_0x5b8223(0x115))[_0x5b8223(0x10c)](/end_expire_time":\d+/g,_0x5b8223(0x10b))['replace'](/hide_full_ad":\d/g,_0x5b8223(0x117))[_0x5b8223(0x10c)](/sub_status":\d/g,_0x5b8223(0x111)),$done({'body':body}));
