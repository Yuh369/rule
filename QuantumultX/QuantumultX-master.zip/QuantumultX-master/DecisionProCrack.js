/******************************

脚本功能：小决定解锁永久高级版
软件版本：2.16
下载地址：http://t.cn/A6Kgep6z
脚本作者：Passer_by_yun
更新时间：2023-01-01
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 小决定解锁永久高级版
^https?:\/\/api\.revenuecat\.com\/v1\/(receipts|subscribers\/\$RCAnonymousID%3A\w{32})$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/DecisionProCrack.js

[mitm] 
hostname = api.revenuecat.com

*******************************/

var _0x4633fd=_0x4af4;function _0x4af4(_0x3a266f,_0x28458f){var _0x4d1f4b=_0x4d1f();return _0x4af4=function(_0x4af420,_0x12bdb2){_0x4af420=_0x4af420-0x1db;var _0x5e6065=_0x4d1f4b[_0x4af420];return _0x5e6065;},_0x4af4(_0x3a266f,_0x28458f);}(function(_0x44e238,_0x2b1d7b){var _0x1b77a8=_0x4af4,_0x268f67=_0x44e238();while(!![]){try{var _0x232f53=parseInt(_0x1b77a8(0x1dd))/0x1*(parseInt(_0x1b77a8(0x1e0))/0x2)+-parseInt(_0x1b77a8(0x1e7))/0x3+-parseInt(_0x1b77a8(0x1eb))/0x4*(-parseInt(_0x1b77a8(0x1e8))/0x5)+parseInt(_0x1b77a8(0x1dc))/0x6+-parseInt(_0x1b77a8(0x1ed))/0x7+-parseInt(_0x1b77a8(0x1e6))/0x8*(-parseInt(_0x1b77a8(0x1e3))/0x9)+parseInt(_0x1b77a8(0x1de))/0xa*(-parseInt(_0x1b77a8(0x1e4))/0xb);if(_0x232f53===_0x2b1d7b)break;else _0x268f67['push'](_0x268f67['shift']());}catch(_0x7f63b9){_0x268f67['push'](_0x268f67['shift']());}}}(_0x4d1f,0x8e41b));function _0x4d1f(){var _0x2af7f5=['2021-11-22T00:35:31Z','13518BNFLKD','93929bYZwaZ','https://apps.apple.com/account/subscriptions','3056HBrywT','3149199QhmkWl','329605IJAHcY','2023-01-01T11:11:02Z','2023-01-01T11:09:05Z','8yWEdgh','2023-01-01T11:12:01Z','204428ifevBG','app_store','stringify','trial','body','com.nixwang.decision.pro.annual','1637448rYimJS','486716WXvFQH','340GiYNVG','$RCAnonymousID:3e2fc67a09c84c14a79940e400ad5bc4','4AcKBQq','parse'];_0x4d1f=function(){return _0x2af7f5;};return _0x4d1f();}var body=$response[_0x4633fd(0x1f1)],objc=JSON[_0x4633fd(0x1e1)](body);objc={'request_date_ms':0x1856d080890,'request_date':_0x4633fd(0x1ec),'subscriber':{'non_subscriptions':{},'first_seen':_0x4633fd(0x1ea),'original_application_version':'114','other_purchases':{},'management_url':_0x4633fd(0x1e5),'subscriptions':{'com.nixwang.decision.pro.annual':{'original_purchase_date':'2023-01-01T11:11:04Z','expires_date':'2999-11-28T09:00:00Z','is_sandbox':![],'refunded_at':null,'unsubscribe_detected_at':null,'grace_period_expires_date':null,'period_type':_0x4633fd(0x1f0),'purchase_date':'2023-01-01T11:11:02Z','billing_issues_detected_at':null,'ownership_type':'PURCHASED','store':_0x4633fd(0x1ee),'auto_resume_date':null}},'entitlements':{'com.nixwang.decision.entitlements.pro':{'grace_period_expires_date':null,'purchase_date':_0x4633fd(0x1e9),'product_identifier':_0x4633fd(0x1db),'expires_date':'2999-11-28T09:00:00Z'}},'original_purchase_date':_0x4633fd(0x1e2),'original_app_user_id':_0x4633fd(0x1df),'last_seen':_0x4633fd(0x1ea)}},body=JSON[_0x4633fd(0x1ef)](objc),$done({'body':body});
