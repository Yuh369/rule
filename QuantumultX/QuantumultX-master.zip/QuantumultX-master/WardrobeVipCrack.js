/******************************

脚本功能：尽简衣橱解锁永久会员
软件版本：2.7.0
下载地址：http://t.cn/A6KyHDkl
脚本作者：Hausd0rff
更新时间：2022-11-19
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 尽简衣橱解锁永久会员
^https?:\/\/closet\.jinjian\.tech\/api\/v3\/apple_app_store\/resolve_receipt$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/WardrobeVipCrack.js

[mitm] 
hostname = closet.jinjian.tech

*******************************/

var _0x69328c=_0x15e6;(function(_0x1efb08,_0x3eeb9e){var _0x11c52c=_0x15e6,_0x49da9b=_0x1efb08();while(!![]){try{var _0x3acf11=parseInt(_0x11c52c(0x151))/0x1+-parseInt(_0x11c52c(0x160))/0x2*(parseInt(_0x11c52c(0x156))/0x3)+-parseInt(_0x11c52c(0x15c))/0x4+parseInt(_0x11c52c(0x159))/0x5+-parseInt(_0x11c52c(0x157))/0x6*(parseInt(_0x11c52c(0x15b))/0x7)+parseInt(_0x11c52c(0x161))/0x8*(parseInt(_0x11c52c(0x158))/0x9)+-parseInt(_0x11c52c(0x15f))/0xa*(-parseInt(_0x11c52c(0x152))/0xb);if(_0x3acf11===_0x3eeb9e)break;else _0x49da9b['push'](_0x49da9b['shift']());}catch(_0x27c1dc){_0x49da9b['push'](_0x49da9b['shift']());}}}(_0x3695,0x89043));function _0x15e6(_0x12833e,_0x53f206){var _0x36955f=_0x3695();return _0x15e6=function(_0x15e6de,_0x8a3da7){_0x15e6de=_0x15e6de-0x14f;var _0x59f8a2=_0x36955f[_0x15e6de];return _0x59f8a2;},_0x15e6(_0x12833e,_0x53f206);}function _0x3695(){var _0x3d326a=['6jltfUB','207beSapC','371545buuOCr','data','5977853ZomHkW','1427336JETIbS','expired_at','parse','410470yhbHRI','16iQScMF','307808YGrkoB','type','body','745102fZHjXE','77ARtjmI','premium','stringify','type_text','82371RVqFJW'];_0x3695=function(){return _0x3d326a;};return _0x3695();}var body=$response[_0x69328c(0x150)],objc=JSON[_0x69328c(0x15e)](body);objc[_0x69328c(0x15a)][_0x69328c(0x14f)]=_0x69328c(0x153),objc[_0x69328c(0x15a)][_0x69328c(0x155)]='\x68\x74\x74\x70\x73\x3a\x2f\x2f\x74\x2e\x6d\x65\x2f\x79\x71\x63\x5f\x31\x32\x33 \u5df2\u4e3a\u60a8\u7834\u89e3\u6c38\u4e45\u4f1a\u5458',objc[_0x69328c(0x15a)][_0x69328c(0x15d)]='\x32\x39\x39\x39\x2d\x30\x39\x2d\x32\x38\x20\x30\x36\x3a\x30\x36\x3a\x30\x36',$done({'body':JSON[_0x69328c(0x154)](objc)});
