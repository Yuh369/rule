/******************************

脚本功能：Style Art解锁永久会员
软件版本：1.1.0
下载地址：http://t.cn/A6KJ3Fhs
脚本作者：Passer_by_yun
更新时间：2022-12-05
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > Style Art解锁永久会员
^https?:\/\/api-aidraw\.3dmoxiu\.com\/v4\/aidraw\/user\/userInfo\/getUserInfoByToken$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/StyleArtProCrack.js

[mitm] 
hostname = api-aidraw.3dmoxiu.com

*******************************/

function _0x105d(_0x59255e,_0x35f31a){var _0x8f6986=_0x8f69();return _0x105d=function(_0x105d00,_0x57c310){_0x105d00=_0x105d00-0xbd;var _0x1b0ad6=_0x8f6986[_0x105d00];return _0x1b0ad6;},_0x105d(_0x59255e,_0x35f31a);}var _0x32b33a=_0x105d;(function(_0xc8595f,_0x57efbf){var _0x1fe3a7=_0x105d,_0x3b9bd5=_0xc8595f();while(!![]){try{var _0x23dc1d=parseInt(_0x1fe3a7(0xc8))/0x1+-parseInt(_0x1fe3a7(0xcd))/0x2+-parseInt(_0x1fe3a7(0xd0))/0x3*(-parseInt(_0x1fe3a7(0xc6))/0x4)+parseInt(_0x1fe3a7(0xc2))/0x5*(-parseInt(_0x1fe3a7(0xcb))/0x6)+-parseInt(_0x1fe3a7(0xcf))/0x7*(-parseInt(_0x1fe3a7(0xcc))/0x8)+parseInt(_0x1fe3a7(0xd2))/0x9*(-parseInt(_0x1fe3a7(0xd3))/0xa)+parseInt(_0x1fe3a7(0xc4))/0xb;if(_0x23dc1d===_0x57efbf)break;else _0x3b9bd5['push'](_0x3b9bd5['shift']());}catch(_0x209f5d){_0x3b9bd5['push'](_0x3b9bd5['shift']());}}}(_0x8f69,0x3e7be));function _0x8f69(){var _0x46e868=['1638095563000','269479FjAfCm','parse','userUnionInfo','384288meOKVj','222248AtUcsZ','351572UMYnMc','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ2aXBMZXZlbCI6IjkiLCJ2aXBFbmREYXRlIjoiMzI0OTU0NzYxNDkwMDAiLCJ2aXBTdGFydERhdGUiOiIxNjM4MDk1NTYzMDAwIiwidmlwU2lnbiI6IjZkMDFhNDYxYWY0ZmUzNGEzMzAwMDg2ZDg2ZjA2YWQ3IiwidmlwVHJhbnNhY3Rpb25JZCI6InllYXJseU9uZSJ9.u9eXcuxyeOhjFpFD9xG_ZAJxZZQJNxO9Y39KALLo4HM','91FlhQwr','120dRlwGo','stringify','3645fxZTDI','10690ZqLcAN','body','data','vipStartDate','vipLevel','vipToken','25xCxPuU','vipEndDate','2881923HDjBTs','yearlyOne','29228bGxVob'];_0x8f69=function(){return _0x46e868;};return _0x8f69();}var objc=JSON[_0x32b33a(0xc9)]($response[_0x32b33a(0xbd)]);objc['data'][_0x32b33a(0xca)][_0x32b33a(0xc0)]='9',objc[_0x32b33a(0xbe)][_0x32b33a(0xca)][_0x32b33a(0xc3)]='32495476149000',objc[_0x32b33a(0xbe)]['userUnionInfo'][_0x32b33a(0xbf)]=_0x32b33a(0xc7),objc[_0x32b33a(0xbe)][_0x32b33a(0xca)]['vipTransactionId']=_0x32b33a(0xc5),objc[_0x32b33a(0xbe)][_0x32b33a(0xc1)]=_0x32b33a(0xce),$done({'body':JSON[_0x32b33a(0xd1)](objc)});
