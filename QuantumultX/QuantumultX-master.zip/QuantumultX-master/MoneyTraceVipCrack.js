/******************************

脚本功能：钱迹解锁终身会员
软件版本：3.0.15
下载地址：http://t.cn/A69ztdZy
脚本作者：Passer_by_yun
更新时间：2023-01-06
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 钱迹解锁终身会员
^https?:\/\/qianji\.xxoojoke\.com\/vip\/configios url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/MoneyTraceVipCrack.js

[mitm] 
hostname = qianji.xxoojoke.com

*******************************/

var _0x74c62f=_0x1f8e;(function(_0x1857fc,_0x30c99b){var _0x30f374=_0x1f8e,_0x5eb1a3=_0x1857fc();while(!![]){try{var _0x3f1541=parseInt(_0x30f374(0x146))/0x1+-parseInt(_0x30f374(0x150))/0x2*(parseInt(_0x30f374(0x148))/0x3)+parseInt(_0x30f374(0x147))/0x4*(parseInt(_0x30f374(0x141))/0x5)+-parseInt(_0x30f374(0x149))/0x6*(parseInt(_0x30f374(0x14b))/0x7)+-parseInt(_0x30f374(0x140))/0x8+parseInt(_0x30f374(0x142))/0x9+parseInt(_0x30f374(0x145))/0xa;if(_0x3f1541===_0x30c99b)break;else _0x5eb1a3['push'](_0x5eb1a3['shift']());}catch(_0x2b7c3c){_0x5eb1a3['push'](_0x5eb1a3['shift']());}}}(_0x4423,0xaf181));function _0x4423(){var _0x2f94d4=['1878AOcuXl','24FItXQK','viptype','866971eydjDh','vipstart','config','data','body','1848BXuUQP','userinfo','1523296HUjUzT','5hFTuCJ','1462203DWTrVm','stringify','parse','4613340CUtirO','750926VCUYzH','2426824xyVgez'];_0x4423=function(){return _0x2f94d4;};return _0x4423();}function _0x1f8e(_0x404e5d,_0x37ec41){var _0x4423d7=_0x4423();return _0x1f8e=function(_0x1f8efd,_0x3f2aff){_0x1f8efd=_0x1f8efd-0x140;var _0x2aae00=_0x4423d7[_0x1f8efd];return _0x2aae00;},_0x1f8e(_0x404e5d,_0x37ec41);}var body=$response[_0x74c62f(0x14f)],obj=JSON[_0x74c62f(0x144)](body);obj['data'][_0x74c62f(0x14d)][_0x74c62f(0x151)][_0x74c62f(0x14a)]=0x64,obj[_0x74c62f(0x14e)][_0x74c62f(0x14d)][_0x74c62f(0x151)][_0x74c62f(0x14c)]=0x635750aa,obj['data'][_0x74c62f(0x14d)][_0x74c62f(0x151)]['vipend']=0xca3a3700,body=JSON[_0x74c62f(0x143)](obj),$done({'body':body});
