/******************************

脚本功能：问真八字解锁永久钻石会员
软件版本：2.1.0
下载地址：http://t.cn/A6CM9OiG
脚本作者：Hausd0rff
更新时间：2023-02-28
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 问真八字解锁永久钻石会员
^https?:\/\/bzpp2\.iwzbz\.com\/api\/v1\.1\/user\/getpwnewios url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/WzbzDiamondVipCrack.js

[mitm] 
hostname = bzpp2.iwzbz.com

*******************************/

var _0x20b17c=_0x44be;(function(_0x4e2aa4,_0x19ff60){var _0x49ce32=_0x44be,_0x5b634d=_0x4e2aa4();while(!![]){try{var _0x3c4da4=parseInt(_0x49ce32(0x11a))/0x1+-parseInt(_0x49ce32(0x11c))/0x2+-parseInt(_0x49ce32(0x117))/0x3+parseInt(_0x49ce32(0x11e))/0x4+parseInt(_0x49ce32(0x11f))/0x5+-parseInt(_0x49ce32(0x11b))/0x6+parseInt(_0x49ce32(0x125))/0x7;if(_0x3c4da4===_0x19ff60)break;else _0x5b634d['push'](_0x5b634d['shift']());}catch(_0x9a6a9e){_0x5b634d['push'](_0x5b634d['shift']());}}}(_0x2a2c,0xf0e25));var objc=JSON[_0x20b17c(0x122)]($response[_0x20b17c(0x119)]);objc[_0x20b17c(0x118)][_0x20b17c(0x11d)]=0x0,objc['data'][_0x20b17c(0x124)]=0x3,objc[_0x20b17c(0x118)][_0x20b17c(0x123)]=0x0,objc[_0x20b17c(0x118)][_0x20b17c(0x120)]='2999-11-28\x2006:06:06',$done({'body':JSON[_0x20b17c(0x121)](objc)});function _0x44be(_0x38c66b,_0x29fd61){var _0x2a2c70=_0x2a2c();return _0x44be=function(_0x44bea2,_0x44b24f){_0x44bea2=_0x44bea2-0x117;var _0x402290=_0x2a2c70[_0x44bea2];return _0x402290;},_0x44be(_0x38c66b,_0x29fd61);}function _0x2a2c(){var _0x1dc302=['2364582pAogVJ','3685240UCycmu','adtype','3387488vPNeVP','6694650itCsTe','expires','stringify','parse','vipTipsType','vipLevel','8510880NWRlML','4041471ONapQz','data','body','1168893BUgzWq'];_0x2a2c=function(){return _0x1dc302;};return _0x2a2c();}
