/******************************

脚本功能：SparkMail解锁永久订阅
软件版本：3.0.6
下载地址：http://t.cn/A6Kc7abd
脚本作者：Passer_by_yun
更新时间：2022-11-18
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > SparkMail解锁永久订阅
^https?:\/\/api\.revenuecat\.com\/v1\/(receipts|subscribers\/.{36}|subscribers\/\w{14})$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/SparkMailProCrack.js

[mitm] 
hostname = api.revenuecat.com

*******************************/

function _0x1f44(){var _0x536e60=['parse','2610690wMkikj','657948zGqxeW','2lQudST','730866xpcWeR','spark_5999_1y_1w0','2022-11-18T04:00:12Z','553276ekGmEn','512496CXOmYO','12704prQdud','261PIwLEN','app_store','77nIGRjz','2013-08-01T07:00:00Z','4ulEnYT','Passer_by_yun','PURCHASED','normal','14HXXTht','stringify','2077-07-07T00:00:00Z','1.0','2910595NGCDEY'];_0x1f44=function(){return _0x536e60;};return _0x1f44();}var _0x4490ef=_0x1ac3;function _0x1ac3(_0xe143b7,_0x15718a){var _0x1f4415=_0x1f44();return _0x1ac3=function(_0x1ac362,_0x3eb8d7){_0x1ac362=_0x1ac362-0x74;var _0x1977db=_0x1f4415[_0x1ac362];return _0x1977db;},_0x1ac3(_0xe143b7,_0x15718a);}(function(_0x4cdc32,_0x319940){var _0x2270a8=_0x1ac3,_0x29c8c4=_0x4cdc32();while(!![]){try{var _0x3a9acd=-parseInt(_0x2270a8(0x77))/0x1*(-parseInt(_0x2270a8(0x8a))/0x2)+parseInt(_0x2270a8(0x78))/0x3+parseInt(_0x2270a8(0x7e))/0x4*(-parseInt(_0x2270a8(0x86))/0x5)+parseInt(_0x2270a8(0x74))/0x6*(parseInt(_0x2270a8(0x82))/0x7)+parseInt(_0x2270a8(0x79))/0x8*(parseInt(_0x2270a8(0x7a))/0x9)+parseInt(_0x2270a8(0x88))/0xa+parseInt(_0x2270a8(0x7c))/0xb*(-parseInt(_0x2270a8(0x89))/0xc);if(_0x3a9acd===_0x319940)break;else _0x29c8c4['push'](_0x29c8c4['shift']());}catch(_0x2f75d7){_0x29c8c4['push'](_0x29c8c4['shift']());}}}(_0x1f44,0x4b6c1));var body=$response['body'],obj=JSON[_0x4490ef(0x87)](body);obj={'request_date_ms':0x18488ede92e,'request_date':'2022-11-18T04:10:03Z','subscriber':{'non_subscriptions':{},'first_seen':'2022-11-18T04:02:28Z','original_application_version':_0x4490ef(0x85),'other_purchases':{},'management_url':'https://apps.apple.com/account/subscriptions','subscriptions':{'spark_5999_1y_1w0':{'original_purchase_date':'2022-11-18T03:57:16Z','expires_date':_0x4490ef(0x84),'is_sandbox':![],'refunded_at':null,'unsubscribe_detected_at':null,'grace_period_expires_date':null,'period_type':_0x4490ef(0x81),'purchase_date':_0x4490ef(0x76),'billing_issues_detected_at':null,'ownership_type':_0x4490ef(0x80),'store':_0x4490ef(0x7b),'auto_resume_date':null}},'entitlements':{'premium':{'grace_period_expires_date':null,'purchase_date':_0x4490ef(0x76),'product_identifier':_0x4490ef(0x75),'expires_date':_0x4490ef(0x84)}},'original_purchase_date':_0x4490ef(0x7d),'original_app_user_id':_0x4490ef(0x7f),'last_seen':'2022-11-18T04:02:28Z'}},body=JSON[_0x4490ef(0x83)](obj),$done({'body':body});
