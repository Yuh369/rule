/******************************

脚本功能：VivaCut解锁永久订阅
软件版本：3.0.0
下载地址：http://t.cn/A6KGiuTa
脚本作者：Hausd0rff
更新时间：2022-11-20
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > VivaCut解锁永久订阅
^https?:\/\/medi\.dxzzy321\.top\/api\/rest\/commerce\/integrate\/vip\/perform$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/VivaCutProCrack.js

[mitm] 
hostname = medi.dxzzy321.top

*******************************/

var _0x77ff79=_0x20ab;(function(_0xdd33ed,_0x556528){var _0x7742ee=_0x20ab,_0xe8310d=_0xdd33ed();while(!![]){try{var _0x2676c9=-parseInt(_0x7742ee(0x119))/0x1*(-parseInt(_0x7742ee(0x122))/0x2)+-parseInt(_0x7742ee(0x116))/0x3+-parseInt(_0x7742ee(0x120))/0x4*(-parseInt(_0x7742ee(0x121))/0x5)+parseInt(_0x7742ee(0x115))/0x6*(-parseInt(_0x7742ee(0x11e))/0x7)+parseInt(_0x7742ee(0x114))/0x8*(-parseInt(_0x7742ee(0x118))/0x9)+-parseInt(_0x7742ee(0x123))/0xa+parseInt(_0x7742ee(0x11c))/0xb;if(_0x2676c9===_0x556528)break;else _0xe8310d['push'](_0xe8310d['shift']());}catch(_0x282c1a){_0xe8310d['push'](_0xe8310d['shift']());}}}(_0x347d,0xb156a));function _0x20ab(_0x544e0b,_0x5dc671){var _0x347da4=_0x347d();return _0x20ab=function(_0x20ab92,_0x38814b){_0x20ab92=_0x20ab92-0x114;var _0x5e397e=_0x347da4[_0x20ab92];return _0x5e397e;},_0x20ab(_0x544e0b,_0x5dc671);}function _0x347d(){var _0x95fb80=['list','350001382673885','9188dbb30b0beaf6f0b2363e9c88ae4e','stringify','8xkXHXG','7722930YvriiM','2802579imkgYQ','hasFreedTrialProds','9958473TgvXkc','9kcCDVg','hasIntroOfferProds','hasPurchasedProds','57491522MWvfiq','VivaCut_Yearly_Pro','7QUGdLK','data','5204OTVBpr','75eniFLy','822ZTnfih','11954930HYTNNs'];_0x347d=function(){return _0x95fb80;};return _0x347d();}var objc=JSON['parse']($response['body']);objc[_0x77ff79(0x11f)][_0x77ff79(0x117)]=[],objc[_0x77ff79(0x11f)][_0x77ff79(0x11b)][0x0]=_0x77ff79(0x11d),objc['data'][_0x77ff79(0x11a)][0x0]=_0x77ff79(0x11d),objc[_0x77ff79(0x11f)][_0x77ff79(0x124)]=[{'autoRenewProductId':_0x77ff79(0x11d),'autoRenewStatus':!![],'endTime':0x1d8df1500b08,'isTrialPeriod':![],'orderId':_0x77ff79(0x125),'orderStatus':0x1,'originalOrderId':_0x77ff79(0x125),'productId':_0x77ff79(0x11d),'productType':0x3,'sign':_0x77ff79(0x126),'startTime':0x182361fd4c0}],$done({'body':JSON[_0x77ff79(0x127)](objc)});
