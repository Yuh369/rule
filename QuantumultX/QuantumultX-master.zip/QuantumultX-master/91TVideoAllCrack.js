/******************************

脚本功能：91TV破解全部视频
软件版本：1.0
下载地址：https://bit.ly/3Yu82CM
脚本作者：Hausd0rff
更新时间：2023-02-06
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 91TV破解全部视频
^https?:\/\/.*\/m\w{5}\/m\w{3}-\w{7}\/.*\/index.* url script-request-header https://raw.githubusercontent.com/yqc007/QuantumultX/master/91TVideoAllCrack.js

[mitm] 
hostname = chvtv.xcsxchen.xyz, oqxv.8r09phi.com, iwx68v.8gbhr.com

*******************************/

var _0x3e1295=_0x44dc;(function(_0x55eeda,_0x53ea73){var _0x4cc2ee=_0x44dc,_0x1f99a9=_0x55eeda();while(!![]){try{var _0x15fa5d=parseInt(_0x4cc2ee(0x1e6))/0x1*(parseInt(_0x4cc2ee(0x1e4))/0x2)+parseInt(_0x4cc2ee(0x1e9))/0x3*(parseInt(_0x4cc2ee(0x1e7))/0x4)+parseInt(_0x4cc2ee(0x1e8))/0x5+parseInt(_0x4cc2ee(0x1ea))/0x6+-parseInt(_0x4cc2ee(0x1e1))/0x7*(-parseInt(_0x4cc2ee(0x1df))/0x8)+parseInt(_0x4cc2ee(0x1e0))/0x9+-parseInt(_0x4cc2ee(0x1e5))/0xa*(parseInt(_0x4cc2ee(0x1e2))/0xb);if(_0x15fa5d===_0x53ea73)break;else _0x1f99a9['push'](_0x1f99a9['shift']());}catch(_0x2ccec2){_0x1f99a9['push'](_0x1f99a9['shift']());}}}(_0x132e,0x714a1));function _0x132e(){var _0x10a00c=['435XPSTVA','4044102SbielZ','replace','m3u8','664CWPnrm','3180402LefWFu','16576hCnvfp','3773AkAXFU','url','2girpej','63950HmMCjT','611293LZDcra','10668InYHUm','2177855NqXlNa'];_0x132e=function(){return _0x10a00c;};return _0x132e();}var urlq=$request['url'], _0xdcaafd=/m3u8-preview/;function _0x44dc(_0x5627f5,_0x52d90a){var _0x132e7a=_0x132e();return _0x44dc=function(_0x44dcad,_0x3a88f0){_0x44dcad=_0x44dcad-0x1dd;var _0xf0bbb4=_0x132e7a[_0x44dcad];return _0xf0bbb4;},_0x44dc(_0x5627f5,_0x52d90a);}$done({'url':$request[_0x3e1295(0x1e3)][_0x3e1295(0x1dd)](_0xdcaafd,_0x3e1295(0x1de))});
