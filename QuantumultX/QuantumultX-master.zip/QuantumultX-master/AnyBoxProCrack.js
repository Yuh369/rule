/******************************

脚本功能：AnyBox 解锁Pro永久版
软件版本：1.1.3
下载地址：http://t.cn/A6oepg05
脚本作者：Passer_by_yun
更新时间：2022-11-08
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > AnyBox 解锁Pro永久版
^https?:\/\/api\.revenuecat\.com\/v1\/(receipts|subscribers\/.{36}|subscribers\/\$RCAnonymousID%3A\w{32})$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/AnyBoxProCrack.js

[mitm] 
hostname = api.revenuecat.com

*******************************/

function _0x2f7c(){var _0x184ab2=['Passer_by_yun','body','parse','49iMDNuG','5142696wdAiWg','540YiWsnr','1580552HytevH','2022-11-08T10:38:44Z','1807086cPPUXh','1344910XoOVcc','13840FxTzwF','2077-07-07T07:07:07Z','2790873EkzOBe','app_store','trial','4235950QaQMtL'];_0x2f7c=function(){return _0x184ab2;};return _0x2f7c();}var _0x1d6f7c=_0x597b;(function(_0x3a6c4f,_0x2328e9){var _0x24fe0a=_0x597b,_0x152231=_0x3a6c4f();while(!![]){try{var _0x1358c=-parseInt(_0x24fe0a(0x1f0))/0x1+parseInt(_0x24fe0a(0x1ef))/0x2+-parseInt(_0x24fe0a(0x1ec))/0x3*(-parseInt(_0x24fe0a(0x1f1))/0x4)+parseInt(_0x24fe0a(0x1f6))/0x5+parseInt(_0x24fe0a(0x1eb))/0x6+parseInt(_0x24fe0a(0x1fa))/0x7*(-parseInt(_0x24fe0a(0x1ed))/0x8)+parseInt(_0x24fe0a(0x1f3))/0x9;if(_0x1358c===_0x2328e9)break;else _0x152231['push'](_0x152231['shift']());}catch(_0x152c31){_0x152231['push'](_0x152231['shift']());}}}(_0x2f7c,0xc6735));function _0x597b(_0x33c3de,_0x28dc47){var _0x2f7c03=_0x2f7c();return _0x597b=function(_0x597ba0,_0x147093){_0x597ba0=_0x597ba0-0x1eb;var _0x53de85=_0x2f7c03[_0x597ba0];return _0x53de85;},_0x597b(_0x33c3de,_0x28dc47);}var body=$response[_0x1d6f7c(0x1f8)],obj=JSON[_0x1d6f7c(0x1f9)](body);obj={'request_date_ms':0x18456d22a46,'request_date':'2022-11-08T10:38:44Z','subscriber':{'non_subscriptions':{},'first_seen':'2022-11-08T10:38:44Z','original_application_version':null,'other_purchases':{},'management_url':null,'subscriptions':{'cc.anybox.Anybox.annual':{'billing_issues_detected_at':null,'expires_date':_0x1d6f7c(0x1f2),'is_sandbox':![],'original_purchase_date':'2022-11-08T10:38:44Z','period_type':_0x1d6f7c(0x1f5),'purchase_date':_0x1d6f7c(0x1ee),'store':_0x1d6f7c(0x1f4),'unsubscribe_detected_at':null}},'entitlements':{'pro':{'expires_date':_0x1d6f7c(0x1f2),'product_identifier':'cc.anybox.Anybox.annual','purchase_date':_0x1d6f7c(0x1ee)}},'original_purchase_date':null,'original_app_user_id':_0x1d6f7c(0x1f7),'last_seen':'2022-11-08T10:38:44Z'}},body=JSON['stringify'](obj),$done({'body':body});
