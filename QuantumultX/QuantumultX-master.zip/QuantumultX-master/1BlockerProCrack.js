/******************************

脚本功能：1Blocker 解锁永久订阅
软件版本：5.3.3
下载地址：http://t.cn/A6KnWtUu
脚本作者：Passer_by_yun
更新时间：2022-12-23
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 1Blocker 解锁永久订阅
^https?:\/\/api\.revenuecat\.com\/v1\/(receipts|subscribers\/) url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/1BlockerProCrack.js

[mitm] 
hostname = api.revenuecat.com

*******************************/

var _0x38d18d=_0x2d9a;(function(_0x39f478,_0x28a92b){var _0x447e77=_0x2d9a,_0x339ecb=_0x39f478();while(!![]){try{var _0x5daae=-parseInt(_0x447e77(0xa9))/0x1*(-parseInt(_0x447e77(0xa4))/0x2)+-parseInt(_0x447e77(0xb2))/0x3+-parseInt(_0x447e77(0xa3))/0x4*(-parseInt(_0x447e77(0xaf))/0x5)+-parseInt(_0x447e77(0xb4))/0x6+parseInt(_0x447e77(0xa7))/0x7*(-parseInt(_0x447e77(0xa8))/0x8)+-parseInt(_0x447e77(0xae))/0x9+parseInt(_0x447e77(0xad))/0xa;if(_0x5daae===_0x28a92b)break;else _0x339ecb['push'](_0x339ecb['shift']());}catch(_0x59c8e1){_0x339ecb['push'](_0x339ecb['shift']());}}}(_0x4d6b,0x9787c));var body=$response[_0x38d18d(0xaa)],objc=JSON[_0x38d18d(0xa6)](body);function _0x4d6b(){var _0x1c24c8=['parse','504yxeWPm','11880yvFikT','1zdoqFQ','body','itms-apps://apps.apple.com/account/subscriptions','7326E609-FF69-4A99-9B40-EF023E65AA84','2445160NQdUzB','2109717cvfgBa','173110euHaIU','stringify','blocker.ios.subscription.yearly','258495GvyJKP','app_store','800130xyLeSp','2022-12-23T14:46:43Z','900','96SyftVt','212154eexLFd','2999-12-28T11:13:20Z'];_0x4d6b=function(){return _0x1c24c8;};return _0x4d6b();}function _0x2d9a(_0x1c11f7,_0x568253){var _0x4d6b81=_0x4d6b();return _0x2d9a=function(_0x2d9a2e,_0x1eb2dd){_0x2d9a2e=_0x2d9a2e-0xa3;var _0x3e9d9b=_0x4d6b81[_0x2d9a2e];return _0x3e9d9b;},_0x2d9a(_0x1c11f7,_0x568253);}objc={'request_date_ms':0x1853f735cca,'request_date':'2022-12-23T14:46:43Z','subscriber':{'non_subscriptions':{},'first_seen':_0x38d18d(0xb5),'original_application_version':_0x38d18d(0xb6),'other_purchases':{},'management_url':_0x38d18d(0xab),'subscriptions':{'blocker.ios.subscription.yearly':{'is_sandbox':![],'period_type':'premium','billing_issues_detected_at':null,'unsubscribe_detected_at':null,'expires_date':_0x38d18d(0xa5),'grace_period_expires_date':null,'original_purchase_date':_0x38d18d(0xb5),'purchase_date':_0x38d18d(0xb5),'store':_0x38d18d(0xb3)}},'entitlements':{'premium':{'grace_period_expires_date':null,'purchase_date':_0x38d18d(0xb5),'product_identifier':_0x38d18d(0xb1),'expires_date':_0x38d18d(0xa5)}},'original_purchase_date':_0x38d18d(0xb5),'original_app_user_id':_0x38d18d(0xac),'last_seen':_0x38d18d(0xb5)}},body=JSON[_0x38d18d(0xb0)](objc),$done({'body':body});
