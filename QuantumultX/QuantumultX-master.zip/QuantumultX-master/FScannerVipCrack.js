/******************************

脚本功能：极速扫描仪解锁永久会员
软件版本：1.7.9
下载地址：http://t.cn/A6KLMiQL
脚本作者：Hausd0rff
更新时间：2022-11-19
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 极速扫描仪解锁永久会员
^https?:\/\/scanner\.jianse\.tv\/api\/users url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/FScannerVipCrack.js

[mitm] 
hostname = scanner.jianse.tv

*******************************/

function _0x7f9c(_0x507c70,_0xc71f49){var _0x492ce0=_0x492c();return _0x7f9c=function(_0x7f9cd9,_0x3ced1d){_0x7f9cd9=_0x7f9cd9-0x110;var _0x501028=_0x492ce0[_0x7f9cd9];return _0x501028;},_0x7f9c(_0x507c70,_0xc71f49);}var _0x1d6f8f=_0x7f9c;(function(_0x181ae7,_0x450515){var _0x2620e6=_0x7f9c,_0x31dcdb=_0x181ae7();while(!![]){try{var _0x6b25ab=-parseInt(_0x2620e6(0x113))/0x1*(-parseInt(_0x2620e6(0x117))/0x2)+parseInt(_0x2620e6(0x118))/0x3*(-parseInt(_0x2620e6(0x112))/0x4)+parseInt(_0x2620e6(0x11d))/0x5+parseInt(_0x2620e6(0x11a))/0x6*(-parseInt(_0x2620e6(0x111))/0x7)+parseInt(_0x2620e6(0x11c))/0x8+-parseInt(_0x2620e6(0x116))/0x9+parseInt(_0x2620e6(0x11e))/0xa*(parseInt(_0x2620e6(0x115))/0xb);if(_0x6b25ab===_0x450515)break;else _0x31dcdb['push'](_0x31dcdb['shift']());}catch(_0x28929a){_0x31dcdb['push'](_0x31dcdb['shift']());}}}(_0x492c,0x2301e));var body=$response[_0x1d6f8f(0x110)],objc=JSON['parse'](body);objc['id']=0xa2c2a,objc[_0x1d6f8f(0x114)]=!![],objc[_0x1d6f8f(0x11b)]=_0x1d6f8f(0x119),$done({'body':JSON['stringify'](objc)});function _0x492c(){var _0x9eb67d=['2999-09-28\x2006:06:06','29028umrnmC','vipExpireDate','64848WoZnPu','131810arhYAY','4534830FfglYw','body','161HualRO','848oyGFNK','1wGJnEY','vip','11XUUIZd','2323953XWTCyY','132116PRrqQb','582VslSwW'];_0x492c=function(){return _0x9eb67d;};return _0x492c();}
