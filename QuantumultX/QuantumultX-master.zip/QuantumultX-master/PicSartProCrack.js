/******************************

脚本功能：PicSart美易解锁永久订阅
软件版本：21.3.8【美区下载】
下载地址：http://t.cn/A6KjLrDF
脚本作者：Passer_by_yun
更新时间：2022-12-16
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > PicSart美易解锁永久订阅
^https?:\/\/api\.(meiease|picsart)\.cn\/(users\/show\/me|shop\/subscription\/apple\/purchases) url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/PicSartProCrack.js

[mitm] 
hostname = api.meiease.cn, api.picsart.cn

*******************************/

var _0x47527b=_0x11c9;function _0x11c9(_0x2b7917,_0x2e738b){var _0x2374aa=_0x2374();return _0x11c9=function(_0x11c910,_0x7b7b15){_0x11c910=_0x11c910-0xc9;var _0x578251=_0x2374aa[_0x11c910];return _0x578251;},_0x11c9(_0x2b7917,_0x2e738b);}function _0x2374(){var _0x6614b0=['premium_tools_ai','414983PogmoF','subscription_yearly','url','1308IHEsAP','indexOf','/me','483LoYqOE','renewable','premium_tools_standard','810FKWUOY','8065ndxkUI','SUBSCRIPTION_PURCHASED','2yyTATK','7578728ASUnzV','10086','body','1025442NbUIxH','success','1263522SvokKD','/purchases','subscribed','verified_type','gold_old','261635eNJrRX','20442WPhceg','com.picsart.studio.subscription_yearly','yearly','stringify'];_0x2374=function(){return _0x6614b0;};return _0x2374();}(function(_0x5c0d98,_0x3e3f0d){var _0x135ceb=_0x11c9,_0x5da7e5=_0x5c0d98();while(!![]){try{var _0x1f1f68=parseInt(_0x135ceb(0xd8))/0x1*(parseInt(_0x135ceb(0xe4))/0x2)+parseInt(_0x135ceb(0xcd))/0x3+-parseInt(_0x135ceb(0xdb))/0x4*(-parseInt(_0x135ceb(0xe2))/0x5)+parseInt(_0x135ceb(0xd3))/0x6*(parseInt(_0x135ceb(0xde))/0x7)+parseInt(_0x135ceb(0xe5))/0x8+-parseInt(_0x135ceb(0xcb))/0x9+parseInt(_0x135ceb(0xe1))/0xa*(-parseInt(_0x135ceb(0xd2))/0xb);if(_0x1f1f68===_0x3e3f0d)break;else _0x5da7e5['push'](_0x5da7e5['shift']());}catch(_0x4d1996){_0x5da7e5['push'](_0x5da7e5['shift']());}}}(_0x2374,0x7b6a5));var body=$response[_0x47527b(0xca)],url=$request[_0x47527b(0xda)],obj=JSON['parse'](body);url[_0x47527b(0xdc)](_0x47527b(0xdd))!=-0x1&&(obj[_0x47527b(0xd0)]=_0x47527b(0xcf));url[_0x47527b(0xdc)](_0x47527b(0xce))!=-0x1&&(obj={'status':_0x47527b(0xcc),'response':[{'is_eligible_for_grant':![],'limitation':{'max_count':0xa,'limits_exceeded':![]},'expire_date':0x315f366d800,'order_id':_0x47527b(0xc9),'purchase_date':0x1848fdbd660,'original_order_id':'10086','reason':'ok','is_eligible_for_introductory':!![],'subscription_id':_0x47527b(0xd4),'is_trial':![],'status':_0x47527b(0xe3),'plan_meta':{'product_id':_0x47527b(0xd9),'frequency':_0x47527b(0xd5),'scope_id':'full','id':'com.picsart.studio.subscription_yearly','storage_limit_in_mb':0x5000,'level':0x7d0,'type':_0x47527b(0xdf),'tier_id':_0x47527b(0xd1),'permissions':[_0x47527b(0xe0),_0x47527b(0xd7)]}}]});body=JSON[_0x47527b(0xd6)](obj),$done({'body':body});
