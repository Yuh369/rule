/******************************

脚本功能：格志日记解锁永久高级版
软件版本：3.2.1
下载地址：http://t.cn/A6oDgPyl
脚本作者：Hausd0rff
更新时间：2022-11-13
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 格志日记解锁永久高级版
^https?:\/\/diary-id\.sumi\.io\/api\/profile$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/GridDiary2ProCrack.js

[mitm] 
hostname = diary-id.sumi.io

*******************************/

function _0x255b(_0x5e9921,_0xa59547){var _0x1c9ef1=_0x1c9e();return _0x255b=function(_0x255baf,_0x331f44){_0x255baf=_0x255baf-0xba;var _0x346ff6=_0x1c9ef1[_0x255baf];return _0x346ff6;},_0x255b(_0x5e9921,_0xa59547);}var _0x504c16=_0x255b;function _0x1c9e(){var _0x3ab10d=['expires_at','384Ntkdrx','membership_status','42ItAgNS','734799vjNdKW','21123pMMLXy','data','479855LKuXAP','296847QBIiVb','5059446manklc','1859304DJsKXy','body','parse','2432000SDOLjM','premium'];_0x1c9e=function(){return _0x3ab10d;};return _0x1c9e();}(function(_0x2f4383,_0x39032b){var _0x863f5c=_0x255b,_0x19a31d=_0x2f4383();while(!![]){try{var _0x53c221=-parseInt(_0x863f5c(0xc8))/0x1+parseInt(_0x863f5c(0xbf))/0x2+-parseInt(_0x863f5c(0xba))/0x3+parseInt(_0x863f5c(0xc2))/0x4+-parseInt(_0x863f5c(0xbc))/0x5*(-parseInt(_0x863f5c(0xc7))/0x6)+parseInt(_0x863f5c(0xbe))/0x7+parseInt(_0x863f5c(0xc5))/0x8*(-parseInt(_0x863f5c(0xbd))/0x9);if(_0x53c221===_0x39032b)break;else _0x19a31d['push'](_0x19a31d['shift']());}catch(_0x640594){_0x19a31d['push'](_0x19a31d['shift']());}}}(_0x1c9e,0x943e3));var body=$response[_0x504c16(0xc0)],objc=JSON[_0x504c16(0xc1)](body);objc[_0x504c16(0xbb)][_0x504c16(0xc6)]=_0x504c16(0xc3),objc[_0x504c16(0xbb)][_0x504c16(0xc4)]='2999-09-28T09:06:22.000000',$done({'body':JSON['stringify'](objc)});
