/******************************

脚本功能：逼哩涩漫解锁付费动漫
软件版本：1.0.11+109
下载地址：https://bit.ly/42VS7jN
脚本作者：Hausd0rff
更新时间：2023-04-21
脚本发布：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️此脚本仅供学习与交流，
        请勿转载与贩卖！⚠️⚠️⚠️
*******************************
[rewrite_local]
# > 逼哩涩漫解锁付费动漫
^https?:\/\/.*\/api\/app\/(user\/info|cartoon\/play|photo\/detail) url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/BiliCartcoonCrack.js

[mitm] 
hostname = etryj.avjfph.com, zhfvd.rjxxqf.com, ryuhf.jmzkwt.com, ovhdo.cjppdp.com

*******************************/

const _0x136edf=_0x55d3;function _0x55d3(_0x15c396,_0x494712){const _0x467ab4=_0x467a();return _0x55d3=function(_0x55d309,_0x538c2c){_0x55d309=_0x55d309-0xe8;let _0x208b99=_0x467ab4[_0x55d309];return _0x208b99;},_0x55d3(_0x15c396,_0x494712);}(function(_0x4183b6,_0x5ebc4d){const _0x3aa474=_0x55d3,_0x1b3bf4=_0x4183b6();while(!![]){try{const _0x593a97=parseInt(_0x3aa474(0x115))/0x1*(-parseInt(_0x3aa474(0xe9))/0x2)+-parseInt(_0x3aa474(0xe8))/0x3+parseInt(_0x3aa474(0xec))/0x4+parseInt(_0x3aa474(0x111))/0x5*(parseInt(_0x3aa474(0x112))/0x6)+-parseInt(_0x3aa474(0x101))/0x7*(-parseInt(_0x3aa474(0xfd))/0x8)+parseInt(_0x3aa474(0xf2))/0x9+-parseInt(_0x3aa474(0xea))/0xa*(-parseInt(_0x3aa474(0xed))/0xb);if(_0x593a97===_0x5ebc4d)break;else _0x1b3bf4['push'](_0x1b3bf4['shift']());}catch(_0x5ca281){_0x1b3bf4['push'](_0x1b3bf4['shift']());}}}(_0x467a,0xf13ea));var body=$response[_0x136edf(0xff)],urlq=$request[_0x136edf(0x107)],objc=JSON[_0x136edf(0x104)](body);const yqc_123=_0x136edf(0xf5),yqc_666=_0x136edf(0x108),yqc_688=_0x136edf(0x10e),yqc_777=_0x136edf(0xf6),yqc_778=_0x136edf(0xf7);urlq[_0x136edf(0x102)](yqc_123)!=-0x1&&(objc['data']['id']=0x278b,objc['data']['vipType']=0xc,objc[_0x136edf(0xf8)][_0x136edf(0x100)]=yqc_777,objc['data'][_0x136edf(0xee)]=0x790e19db5,objc[_0x136edf(0xf8)]['vipExpireTime']='2999-11-28T08:59:59.128666868+08:06',objc[_0x136edf(0xf8)][_0x136edf(0x110)]=_0x136edf(0x113),objc[_0x136edf(0xf8)]['totalWatchTimes']=0xa2c2a,objc['data'][_0x136edf(0x10f)]=0xa2c2a,objc[_0x136edf(0xf8)][_0x136edf(0x10a)]=0xa2c2a,objc[_0x136edf(0xf8)]['leftWatchTimes']=0xa2c2a,objc['data'][_0x136edf(0xef)]=0xa2c2a,objc['data'][_0x136edf(0x10c)]=0xa2c2a,objc[_0x136edf(0xf8)][_0x136edf(0xf4)]=0xa2c2a,objc[_0x136edf(0xf8)][_0x136edf(0x10b)]=0xa2c2a,objc['data'][_0x136edf(0x109)]=_0x136edf(0x105),objc['data'][_0x136edf(0xf0)]=yqc_778,objc[_0x136edf(0xf8)][_0x136edf(0xfb)]=[{'image':'','isOpen':!![],'type':0x1,'name':'至尊永久卡免费看漫画','desc':_0x136edf(0xfc)},{'image':'','isOpen':!![],'type':0x1,'name':_0x136edf(0xfa),'desc':_0x136edf(0xf3)},{'image':'','isOpen':!![],'type':0x1,'name':_0x136edf(0x10d),'desc':_0x136edf(0xf9)},{'image':_0x136edf(0xeb),'isOpen':!![],'type':0x2,'name':_0x136edf(0xfe),'desc':_0x136edf(0x114)},{'image':_0x136edf(0xeb),'isOpen':!![],'type':0x2,'name':_0x136edf(0x106),'desc':'发表您的评论，与千万B友在线互动'},{'image':'','isOpen':!![],'type':0x3,'name':'发布互动帖子','desc':_0x136edf(0x116)}]);urlq[_0x136edf(0x102)](yqc_666)!=-0x1&&(objc[_0x136edf(0xf8)][_0x136edf(0x103)]=!![]);urlq['indexOf'](yqc_688)!=-0x1&&(objc[_0x136edf(0xf8)][_0x136edf(0xf1)]=!![]);$done({'body':JSON['stringify'](objc)});function _0x467a(){const _0x52aa38=['rights','永久免费观看全站VIP及付费漫画','5830984uqJnvj','情趣表情实时弹幕','body','vipImage','7DAqzqI','indexOf','playable','parse','\u6d65\u8f7b\u5c18 \ud835\udc36\ud835\udc5f\ud835\udc4e\ud835\udc50\ud835\udc58','评论留言','url','/api/app/cartoon/play','nickName','leftDownloadTimes','invites','fans','性福生活时刻精彩','/api/app/photo/detail','totalDownloadTimes','cardName','2162505HETGic','6TrOrKU','次元至尊卡','涩漫独家专享功能，在线追漫趣味满分','138304CugFsN','在社区任意发布帖子，分享您的涩涩生活！','268239mLEBcD','22oXswyR','20XZlJOS','image/hf/2/gi/1x6/be691f4b7fb99348ef2a649d8f2f0f79.png','812856eaVyFO','1144209Axkaho','vipExpire','readTicketCount','avatarUrl','isBought','9236421LVTJTa','永久免费观看全站动漫+原创COS视频','balance','/api/app/user/info','image/t/wj/2lx/vn/21b021020e079eff8b767c2573c316e4.jpg','image/o1/2ts/70/2x4/56eda224b51f90a77c1d51b8b089cae0.jpg','data','永久免费解锁所有楼凤约炮帖子','动漫/原创视频免费看'];_0x467a=function(){return _0x52aa38;};return _0x467a();}
