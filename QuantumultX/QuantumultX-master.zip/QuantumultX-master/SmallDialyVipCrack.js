/******************************

脚本功能：小习惯解锁永久会员
软件版本：4.70
下载地址：http://t.cn/A6Kwj0Le
脚本作者：Hausd0rff
更新时间：2022-11-18
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > 小习惯解锁永久会员
^https?:\/\/xianbeikeji\.com\/daily\/app\/user\/query$ url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/SmallDialyVipCrack.js

[mitm] 
hostname = xianbeikeji.com

*******************************/

var _0x52e2ff=_0x40de;(function(_0x35f3e9,_0x1977c8){var _0x193380=_0x40de,_0x29cabb=_0x35f3e9();while(!![]){try{var _0xc5d8f9=-parseInt(_0x193380(0x120))/0x1*(-parseInt(_0x193380(0x127))/0x2)+-parseInt(_0x193380(0x11e))/0x3+parseInt(_0x193380(0x123))/0x4+-parseInt(_0x193380(0x121))/0x5+parseInt(_0x193380(0x125))/0x6+parseInt(_0x193380(0x11f))/0x7*(-parseInt(_0x193380(0x11a))/0x8)+parseInt(_0x193380(0x119))/0x9*(parseInt(_0x193380(0x124))/0xa);if(_0xc5d8f9===_0x1977c8)break;else _0x29cabb['push'](_0x29cabb['shift']());}catch(_0x322285){_0x29cabb['push'](_0x29cabb['shift']());}}}(_0x5bf6,0x7aa82));var objc=JSON['parse']($response['body']);function _0x40de(_0x2bcd36,_0x440d47){var _0x5bf6d9=_0x5bf6();return _0x40de=function(_0x40de6f,_0x497c88){_0x40de6f=_0x40de6f-0x119;var _0x5d3f20=_0x5bf6d9[_0x40de6f];return _0x5d3f20;},_0x40de(_0x2bcd36,_0x440d47);}objc[_0x52e2ff(0x129)][_0x52e2ff(0x128)][_0x52e2ff(0x11d)]=0x1,objc[_0x52e2ff(0x129)][_0x52e2ff(0x128)][_0x52e2ff(0x126)]=_0x52e2ff(0x11c),objc[_0x52e2ff(0x129)][_0x52e2ff(0x128)][_0x52e2ff(0x122)]=_0x52e2ff(0x11b),$done({'body':JSON['stringify'](objc)});function _0x5bf6(){var _0x48f9d4=['989lsMBdL','4672615pbhygt','avatar','3840656OfoLSX','20TdCueC','1941366cJrahU','nickName','1894zigxrU','userInfo','data','4743099jqIKpt','136lnmdfg','https://thirdqq.qlogo.cn/g?b=oidb&k=iaODNibZcQQTN0QPGShfkKIw&s=640','Hausd0rff\x20Crack','vipFlag','2534886iDqfXm','408653qqwLPn'];_0x5bf6=function(){return _0x48f9d4;};return _0x5bf6();}
