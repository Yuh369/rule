/******************************

脚本功能：AdGuard 解锁永久高级版
软件版本：4.4.5
下载地址：http://t.cn/A6Kmswld
脚本作者：Passer_by_yun
更新时间：2022-12-26
电报频道：https://t.me/yqc_123
问题反馈：https://t.me/yqc_777
使用声明：⚠️仅供学习交流，🈲️商业用途

*******************************

[rewrite_local]
# > AdGuard 解锁永久高级版
^https?:\/\/mobile-api\.adguard\.org\/api\/.+\/ios_validate_receipt url script-response-body https://raw.githubusercontent.com/yqc007/QuantumultX/master/AdGuardProCrack.js

[mitm] 
hostname = *.adguard.org

*******************************/

var _0x4f31d5=_0x12ca;(function(_0x5c1883,_0x17e9a1){var _0x544ae8=_0x12ca,_0x477c65=_0x5c1883();while(!![]){try{var _0x143428=parseInt(_0x544ae8(0xc0))/0x1*(parseInt(_0x544ae8(0xc1))/0x2)+-parseInt(_0x544ae8(0xca))/0x3*(-parseInt(_0x544ae8(0xc7))/0x4)+-parseInt(_0x544ae8(0xc8))/0x5+-parseInt(_0x544ae8(0xc3))/0x6+-parseInt(_0x544ae8(0xc6))/0x7+parseInt(_0x544ae8(0xc4))/0x8+-parseInt(_0x544ae8(0xc9))/0x9;if(_0x143428===_0x17e9a1)break;else _0x477c65['push'](_0x477c65['shift']());}catch(_0x16ed2f){_0x477c65['push'](_0x477c65['shift']());}}}(_0x5c7b,0xab543));function _0x12ca(_0x222957,_0x1cf4f4){var _0x5c7b32=_0x5c7b();return _0x12ca=function(_0x12cab9,_0x19d81e){_0x12cab9=_0x12cab9-0xbf;var _0x5a0581=_0x5c7b32[_0x12cab9];return _0x5a0581;},_0x12ca(_0x222957,_0x1cf4f4);}function _0x5c7b(){var _0x3ee633=['999089TGuJfA','3427288deZfJF','6779030reCFqu','933687RsylaR','3gRYkyg','com.adguard.lifetimePurchase','parse','16683YDGYxP','166cawkvp','stringify','3714462UfLwGc','5452840hRVWxC','ACTIVE'];_0x5c7b=function(){return _0x3ee633;};return _0x5c7b();}var body=$response['body'],obj=JSON[_0x4f31d5(0xbf)](body);obj={'products':[{'product_id':_0x4f31d5(0xcb),'premium_status':_0x4f31d5(0xc5)}]},body=JSON[_0x4f31d5(0xc2)](obj),$done({'body':body});
